// ============================================================
// ZERO DEPENDENCIES SERVER
// No npm install needed — pure Node.js built-in modules only
// ============================================================

const http = require('http');
const fs   = require('fs');
const path = require('path');

// ── Load .env file manually (no dotenv package needed) ─────
function loadEnv() {
  try {
    const content = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    content.split('\n').forEach(line => {
      line = line.trim();
      if (!line || line.startsWith('#')) return;
      const i = line.indexOf('=');
      if (i === -1) return;
      const k = line.slice(0, i).trim();
      let   v = line.slice(i + 1).trim();
      // Remove surrounding quotes if any
      if ((v.startsWith('"') && v.endsWith('"')) ||
          (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      if (!process.env[k]) process.env[k] = v;
    });
    console.log('✅ .env loaded');
  } catch(e) {
    console.warn('⚠️  No .env file found');
  }
}

loadEnv();

// ── Validate API Key ────────────────────────────────────────
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const PORT           = process.env.PORT || 3000;

if (!GEMINI_API_KEY) {
  console.error('❌ GEMINI_API_KEY missing! Add to .env file');
  process.exit(1);
}

console.log('✅ API Key loaded — length:', GEMINI_API_KEY.length);

// ── Rate Limiter (no express-rate-limit needed) ─────────────
const rateLimitMap = new Map();
const RATE_LIMIT   = 10;
const RATE_WINDOW  = 60 * 1000;

function checkRateLimit(ip) {
  const now   = Date.now();
  const entry = rateLimitMap.get(ip) || { count: 0, start: now };
  if (now - entry.start > RATE_WINDOW) {
    rateLimitMap.set(ip, { count: 1, start: now });
    return true;
  }
  if (entry.count >= RATE_LIMIT) return false;
  entry.count++;
  rateLimitMap.set(ip, entry);
  return true;
}

// ── Call Gemini API (tries multiple endpoints) ──────────────
async function callGemini(message) {
  const endpoints = [
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
    `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
  ];

  const body = JSON.stringify({
    contents: [{ parts: [{ text: message }] }]
  });

  for (const url of endpoints) {
    try {
      const res  = await fetch(url, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body
      });
      const data = await res.json();

      // Success
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) {
        console.log('🤖 AI replied ✅');
        return { answer: text };
      }

      // Known errors
      if (data?.error?.status === 'INVALID_ARGUMENT') {
        return { error: 'Message could not be processed. Try rephrasing.' };
      }
      if (data?.error?.status === 'RESOURCE_EXHAUSTED') {
        return { error: 'AI quota exceeded. Try again later.' };
      }
      if (data?.error) {
        console.log('⚠️  Endpoint failed:', data.error.message);
        continue; // try next endpoint
      }

    } catch(e) {
      console.log('⚠️  Fetch error:', e.message);
      continue;
    }
  }

  return { error: 'AI service unavailable. Try again later.' };
}

// ── Read request body ───────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 10240) reject(new Error('Payload too large'));
    });
    req.on('end',   () => resolve(body));
    req.on('error', reject);
  });
}

// ── Input sanitizer ─────────────────────────────────────────
function sanitize(msg) {
  if (typeof msg !== 'string') return null;
  const t = msg.trim();
  if (!t || t.length > 2000) return null;
  return t;
}

// ── MIME types ──────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.ico':  'image/x-icon',
  '.svg':  'image/svg+xml'
};

// ── Main HTTP Server ────────────────────────────────────────
const server = http.createServer(async (req, res) => {

  // CORS
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // ── POST /apicall ──────────────────────────────────────────
  if (req.method === 'POST' && req.url === '/apicall') {

    // Rate limit check
    const ip = req.socket.remoteAddress;
    if (!checkRateLimit(ip)) {
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Too many requests. Please wait a minute.' }));
      return;
    }

    try {
      const raw     = await readBody(req);
      const parsed  = JSON.parse(raw);
      const message = sanitize(parsed?.message);

      if (!message) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Message is required (1–2000 characters).' }));
        return;
      }

      console.log('📨 User:', message.slice(0, 60));
      const result = await callGemini(message);

      if (result.error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: result.error }));
        return;
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ answer: result.answer }));

    } catch(err) {
      console.error('❌ Server error:', err.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Something went wrong. Please try again.' }));
    }
    return;
  }

  // ── GET /health ────────────────────────────────────────────
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', time: new Date().toISOString() }));
    return;
  }

  // ── Serve static files from /public folder ─────────────────
  let filePath = req.url === '/' ? '/public/index.html' : '/public' + req.url;
  filePath = path.join(__dirname, filePath);

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Route ' + req.method + ' ' + req.url + ' not found.' }));
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'text/plain' });
    res.end(data);
  });

});

// ── Start ───────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log('');
  console.log('🚀 Server running → http://localhost:' + PORT);
  console.log('📁 Serving files from /public folder');
  console.log('🤖 Gemini AI ready');
  console.log('✅ Zero npm packages needed!');
  console.log('');
});

// ── Graceful shutdown ───────────────────────────────────────
function shutdown(signal) {
  console.log('\n⚠️  ' + signal + ' received. Shutting down...');
  server.close(() => {
    console.log('✅ Server closed.');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));