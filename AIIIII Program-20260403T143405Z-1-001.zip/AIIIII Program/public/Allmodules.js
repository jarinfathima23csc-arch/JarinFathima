// ============================================================
// AllModules.js — SINGLE MERGED FILE (Production Ready)
// Combines: Modules.js + NewModules.js
// Theme, Voice, Export, Admin, Sound, KB, Analytics,
// Weather, Profile, Backup, Memory, Share, Notification
// ============================================================

// ── MODAL HELPERS ────────────────────────────────────────────
function _showModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.remove('hidden'); el.style.display = 'flex'; }
}
function _hideModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('hidden'); el.style.display = 'none'; }
}
// Close modal on backdrop click
document.addEventListener('click', function(e) {
  ['kb-modal','analytics-modal','location-modal','profile-modal',
   'history-backup-modal','export-modal','admin-panel'].forEach(id => {
    const el = document.getElementById(id);
    if (el && !el.classList.contains('hidden') && e.target === el) _hideModal(id);
  });
});

// ══════════════════════════════════════════════════════════════
// 1. THEME TOGGLE
// ══════════════════════════════════════════════════════════════
(function() {
  const saved = localStorage.getItem('jameeai_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);

  window.toggleTheme = function() {
    const cur  = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('jameeai_theme', next);
    if (typeof showToast === 'function') showToast(next === 'dark' ? '🌙 Dark mode' : '☀️ Light mode');
  };
})();

// ══════════════════════════════════════════════════════════════
// 2. VOICE INPUT (Mic → Text)
// ══════════════════════════════════════════════════════════════
(function() {
  let recognition = null, isListening = false;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition || null;

  window.toggleVoiceInput = function() {
    const btn = document.getElementById('voice-btn');
    if (!SR) { if (typeof showToast === 'function') showToast('❌ Voice needs Chrome.'); return; }
    if (isListening) { if (recognition) recognition.stop(); return; }
    try {
      recognition = new SR();
      recognition.lang = 'en-US';
      recognition.interimResults = true;
      recognition.continuous = false;

      recognition.onstart = function() {
        isListening = true;
        if (btn) { btn.classList.add('voice-active'); btn.title = 'Stop listening'; }
        if (typeof showToast === 'function') showToast('🎙️ Listening…');
      };
      recognition.onresult = function(e) {
        let interim = '', final = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const t = e.results[i][0].transcript;
          if (e.results[i].isFinal) final += t; else interim += t;
        }
        const input = document.getElementById('chat-input');
        if (input) { input.value = final || interim; input.dispatchEvent(new Event('input')); }
      };
      recognition.onerror = function(e) {
        isListening = false;
        if (btn) { btn.classList.remove('voice-active'); btn.title = 'Voice input'; }
        if (e.error === 'not-allowed') { if (typeof showToast === 'function') showToast('❌ Mic blocked. Allow in browser settings.'); }
        else if (e.error === 'no-speech') { if (typeof showToast === 'function') showToast('⚠️ No speech detected.'); }
        else if (e.error !== 'aborted') { if (typeof showToast === 'function') showToast('⚠️ Voice error: ' + e.error); }
      };
      recognition.onend = function() {
        isListening = false;
        if (btn) { btn.classList.remove('voice-active'); btn.title = 'Voice input'; }
        const input   = document.getElementById('chat-input');
        const sendBtn = document.getElementById('send-message');
        if (input && input.value.trim() && sendBtn) setTimeout(() => sendBtn.click(), 300);
      };
      recognition.start();
    } catch (err) { if (typeof showToast === 'function') showToast('❌ ' + err.message); }
  };
})();

// ══════════════════════════════════════════════════════════════
// 3. VOICE OUTPUT (AI reply → speak)
// ══════════════════════════════════════════════════════════════
(function() {
  let voOn = localStorage.getItem('jameeai_voice_out') === 'on';

  window.toggleVoiceOutput = function() {
    voOn = !voOn;
    localStorage.setItem('jameeai_voice_out', voOn ? 'on' : 'off');
    const btn = document.getElementById('voice-out-btn');
    if (btn) btn.style.color = voOn ? '#10b981' : '';
    if (typeof showToast === 'function') showToast(voOn ? '🔊 Voice output ON' : '🔇 Voice output OFF');
  };

  window.speakIfEnabled = function(text) {
    if (!voOn) return;
    if (window.speechSynthesis.speaking) window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ''));
    u.rate = 1.05; u.pitch = 1; u.volume = 0.9;
    window.speechSynthesis.speak(u);
  };
})();

// ══════════════════════════════════════════════════════════════
// 4. CHAT EXPORT (PDF / TXT)
// ══════════════════════════════════════════════════════════════
(function() {
  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function dl(blob, name) { const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: name }); document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }
  function stamp() { return new Date().toISOString().slice(0, 10); }

  window.exportChatTXT = function() {
    const conv = (typeof getActiveConv === 'function') ? getActiveConv() : null;
    if (!conv || !conv.messages.length) { if (typeof showToast === 'function') showToast('⚠️ No messages.'); return; }
    const lines = ['Jamee AI Chat Export', '='.repeat(40), ''];
    conv.messages.forEach(m => { lines.push((m.role === 'user' ? '👤 You' : '🤖 AI') + ':'); lines.push(m.content); lines.push(''); });
    lines.push('Exported: ' + new Date().toLocaleString());
    dl(new Blob([lines.join('\n')], { type: 'text/plain' }), 'jameeai-chat-' + stamp() + '.txt');
    if (typeof showToast === 'function') showToast('✅ Exported as TXT!');
  };

  window.exportChatPDF = function() {
    const conv = (typeof getActiveConv === 'function') ? getActiveConv() : null;
    if (!conv || !conv.messages.length) { if (typeof showToast === 'function') showToast('⚠️ No messages.'); return; }
    const rows = conv.messages.map(m => {
      const iu = m.role === 'user';
      return `<div style="margin:0 0 14px;padding:12px 16px;background:${iu?'#1e1b4b':'#0f172a'};border-radius:10px;border-left:3px solid ${iu?'#a78bfa':'#10b981'}">
        <div style="font-size:11px;font-weight:700;color:${iu?'#a78bfa':'#10b981'};margin-bottom:6px;">${iu?'👤 You':'🤖 AI'}</div>
        <div style="font-size:13px;line-height:1.6;white-space:pre-wrap;">${esc(m.content)}</div></div>`;
    }).join('');
    const w = window.open('', '_blank');
    if (!w) { if (typeof showToast === 'function') showToast('❌ Pop-up blocked.'); return; }
    w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Chat Export</title>
      <style>body{font-family:Arial,sans-serif;background:#0a0a0a;color:#e5e5e5;padding:32px;max-width:800px;margin:auto;}
      h2{color:#a78bfa;}@media print{body{background:#fff;color:#000;}}</style></head><body>
      <h2>Jamee AI Chat Export</h2><p style="color:#888;font-size:12px;margin-bottom:24px">Exported: ${new Date().toLocaleString()} | ${conv.messages.length} messages</p>
      ${rows}</body></html>`);
    w.document.close();
    setTimeout(() => { w.focus(); w.print(); }, 400);
    if (typeof showToast === 'function') showToast('🖨️ PDF dialog opened!');
  };

  window.openExportModal  = function() { _showModal('export-modal'); };
  window.closeExportModal = function() { _hideModal('export-modal'); };
})();

// ══════════════════════════════════════════════════════════════
// 5. ADMIN PANEL
// ══════════════════════════════════════════════════════════════
(function() {
  function lu() { try { return JSON.parse(localStorage.getItem('jameeai_users') || '{}'); } catch(e) { return {}; } }
  function la() { try { return JSON.parse(localStorage.getItem('jameeai_admins') || '["admin"]'); } catch(e) { return ['admin']; } }
  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  function render() {
    const users = lu(), admins = la();
    const tbody = document.getElementById('admin-user-tbody');
    const counter = document.getElementById('admin-user-count');
    if (!tbody) return;
    if (counter) counter.textContent = Object.keys(users).length + ' users';
    tbody.innerHTML = '';
    if (!Object.keys(users).length) { tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;padding:20px;color:#888">No users.</td></tr>'; return; }
    Object.keys(users).forEach(u => {
      const ia = admins.includes(u);
      const tr = document.createElement('tr');
      tr.innerHTML = `<td><div style="display:flex;align-items:center;gap:8px;"><div style="width:28px;height:28px;border-radius:50%;background:#a78bfa22;border:1px solid #a78bfa44;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#a78bfa">${u[0].toUpperCase()}</div><span>${esc(u)}</span></div></td>
        <td><span class="admin-role-badge ${ia?'badge-admin':'badge-user'}">${ia?'🛡️ Admin':'👤 User'}</span></td>
        <td><div style="display:flex;gap:6px;justify-content:flex-end;">
          <button class="adm-btn adm-toggle" data-action="adminToggleRole" data-user="${esc(u)}">${ia?'↓ User':'↑ Admin'}</button>
          <button class="adm-btn adm-del"    data-action="adminDeleteUser" data-user="${esc(u)}">🗑️</button>
        </div></td>`;
      tbody.appendChild(tr);
    });
  }

  window.openAdminPanel  = function() { _showModal('admin-panel'); render(); };
  window.closeAdminPanel = function() { _hideModal('admin-panel'); };

  window.adminToggleRole = function(u) {
    const a = la(), i = a.indexOf(u);
    if (i === -1) a.push(u); else a.splice(i, 1);
    localStorage.setItem('jameeai_admins', JSON.stringify(a));
    render();
    if (typeof showToast === 'function') showToast(i === -1 ? `🛡️ ${u} is Admin` : `👤 ${u} is User`);
  };

  window.adminDeleteUser = function(u) {
    if (!confirm(`Delete "${u}"?`)) return;
    const users = lu(); delete users[u];
    localStorage.setItem('jameeai_users', JSON.stringify(users));
    const a = la().filter(x => x !== u);
    localStorage.setItem('jameeai_admins', JSON.stringify(a));
    render();
    if (typeof showToast === 'function') showToast(`🗑️ "${u}" deleted.`);
  };

  window.adminAddUser = function() {
    const ui = document.getElementById('admin-new-username');
    const pi = document.getElementById('admin-new-password');
    const err = document.getElementById('admin-add-error');
    const u = (ui?.value || '').trim(), p = (pi?.value || '').trim();
    if (!u || u.length < 3) { if (err) err.textContent = 'Min 3 chars'; return; }
    if (!p || p.length < 4) { if (err) err.textContent = 'Min 4 chars'; return; }
    const users = lu();
    if (users[u]) { if (err) err.textContent = 'Already exists'; return; }
    users[u] = p; localStorage.setItem('jameeai_users', JSON.stringify(users));
    if (err) err.textContent = ''; if (ui) ui.value = ''; if (pi) pi.value = '';
    render();
    if (typeof showToast === 'function') showToast(`✅ "${u}" created!`);
  };
})();

// ══════════════════════════════════════════════════════════════
// 6. NOTIFICATION SOUNDS
// ══════════════════════════════════════════════════════════════
(function() {
  let enabled = localStorage.getItem('jameeai_sound') !== 'off';

  function beep(freq, dur, type, vol) {
    if (!enabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = type || 'sine'; osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(vol || 0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      osc.start(ctx.currentTime); osc.stop(ctx.currentTime + dur);
      osc.onended = () => ctx.close();
    } catch(e) {}
  }

  window.playSoundSend    = function() { beep(880, 0.08, 'sine', 0.12); };
  window.playSoundReceive = function() { beep(523, 0.12, 'sine', 0.15); setTimeout(() => beep(659, 0.18, 'sine', 0.12), 100); };
  window.playSoundError   = function() { beep(220, 0.25, 'sawtooth', 0.1); };
  window.playSoundSuccess = function() { beep(784, 0.1, 'sine', 0.13); setTimeout(() => beep(1047, 0.15, 'sine', 0.10), 90); };

  window.toggleSound = function() {
    enabled = !enabled;
    localStorage.setItem('jameeai_sound', enabled ? 'on' : 'off');
    const btn = document.getElementById('sound-toggle-btn');
    if (btn) { btn.title = enabled ? 'Mute sounds' : 'Enable sounds'; btn.style.opacity = enabled ? '1' : '0.4'; }
    if (enabled) window.playSoundSuccess();
    if (typeof showToast === 'function') showToast(enabled ? '🔔 Sounds ON' : '🔇 Sounds OFF');
  };
  window.isSoundEnabled = function() { return enabled; };
})();

// ══════════════════════════════════════════════════════════════
// 7. KNOWLEDGE BASE
// ══════════════════════════════════════════════════════════════
(function() {
  function kbKey() { return 'jameeai_kb_' + (typeof currentUser !== 'undefined' ? currentUser : 'guest'); }
  function loadKB() { try { return JSON.parse(localStorage.getItem(kbKey()) || '[]'); } catch(e) { return []; } }
  function saveKB(a) { try { localStorage.setItem(kbKey(), JSON.stringify(a)); } catch(e) {} }
  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  function renderKB(filter) {
    const list = document.getElementById('kb-list'); if (!list) return;
    let items = loadKB();
    if (filter) items = items.filter(i => i.q.toLowerCase().includes(filter.toLowerCase()) || i.a.toLowerCase().includes(filter.toLowerCase()));
    list.innerHTML = items.length === 0
      ? '<div class="kb-empty">📭 No entries yet. Add one below!</div>'
      : items.map((item, idx) => `<div class="kb-item">
          <div class="kb-q"><span class="kb-badge">Q</span><span>${esc(item.q)}</span></div>
          <div class="kb-a"><span class="kb-badge kb-badge-a">A</span><span>${esc(item.a)}</span></div>
          <div class="kb-actions"><button class="kb-btn kb-del" data-action="kbDelete" data-idx="${idx}">🗑️ Delete</button></div>
        </div>`).join('');
  }

  window.openKB  = function() { _showModal('kb-modal'); renderKB(); const s = document.getElementById('kb-search'); if (s) { s.value = ''; s.oninput = () => renderKB(s.value); } };
  window.closeKB = function() { _hideModal('kb-modal'); };

  window.kbAdd = function() {
    const q = (document.getElementById('kb-new-q')?.value || '').trim();
    const a = (document.getElementById('kb-new-a')?.value || '').trim();
    const err = document.getElementById('kb-error');
    if (!q) { if (err) err.textContent = '⚠️ Question required.'; return; }
    if (!a) { if (err) err.textContent = '⚠️ Answer required.'; return; }
    if (err) err.textContent = '';
    const items = loadKB(); items.unshift({ q, a, ts: Date.now() }); saveKB(items);
    document.getElementById('kb-new-q').value = '';
    document.getElementById('kb-new-a').value = '';
    renderKB();
    if (typeof showToast === 'function') showToast('✅ Added to Knowledge Base!');
  };

  window.kbDelete = function(idx) {
    const items = loadKB(); items.splice(idx, 1); saveKB(items); renderKB();
    if (typeof showToast === 'function') showToast('🗑️ Deleted.');
  };

  window.checkKBAnswer = function(userMsg) {
    const lower = userMsg.toLowerCase();
    for (const item of loadKB()) {
      if (lower.includes(item.q.toLowerCase()) || item.q.toLowerCase().includes(lower.slice(0, 30))) return item;
    }
    return null;
  };
})();

// ══════════════════════════════════════════════════════════════
// 8. ANALYTICS
// ══════════════════════════════════════════════════════════════
(function() {
  window.openAnalytics  = function() { _showModal('analytics-modal'); renderAnalytics(); };
  window.closeAnalytics = function() { _hideModal('analytics-modal'); };

  function renderAnalytics() {
    const c = document.getElementById('analytics-content'); if (!c) return;
    const convs = (typeof conversations !== 'undefined') ? conversations : [];
    const tm = convs.reduce((s, x) => s + (x.messages?.length || 0), 0);
    const um = convs.reduce((s, x) => s + (x.messages?.filter(m => m.role === 'user').length || 0), 0);
    const wc = {};
    convs.forEach(x => (x.messages || []).filter(m => m.role === 'user').forEach(m =>
      m.content.toLowerCase().split(/\s+/).forEach(w => {
        w = w.replace(/[^a-z]/g, '');
        if (w.length > 3 && !['what','that','this','with','from','have','will','your','just','about','more'].includes(w))
          wc[w] = (wc[w] || 0) + 1;
      })));
    const tw = Object.entries(wc).sort((a, b) => b[1] - a[1]).slice(0, 8);
    let sk = '0 KB';
    try { const d = localStorage.getItem('jameeai_history_' + (typeof currentUser !== 'undefined' ? currentUser : 'guest')) || ''; sk = (d.length * 2 / 1024).toFixed(1) + ' KB'; } catch(e) {}

    c.innerHTML = `
      <div class="an-grid">
        <div class="an-card"><div class="an-num">${convs.length}</div><div class="an-label">Total Chats</div></div>
        <div class="an-card"><div class="an-num">${tm}</div><div class="an-label">Messages</div></div>
        <div class="an-card"><div class="an-num">${sk}</div><div class="an-label">Storage</div></div>
        <div class="an-card"><div class="an-num">${um}</div><div class="an-label">Your Msgs</div></div>
        <div class="an-card"><div class="an-num">${tm - um}</div><div class="an-label">AI Replies</div></div>
        <div class="an-card"><div class="an-num">${convs.length > 0 ? (tm / convs.length).toFixed(1) : 0}</div><div class="an-label">Avg/Chat</div></div>
      </div>
      ${tw.length > 0 ? `<div class="an-section-title">🔤 Top Keywords</div><div class="an-words">${tw.map(([w,n]) => `<span class="an-word-chip">${w} <span class="an-wcount">${n}</span></span>`).join('')}</div>` : ''}
      <div class="an-section-title" style="margin-top:16px">📋 Recent Chats</div>
      <div class="an-activity">${convs.slice(0, 5).map(x => `<div class="an-act-row"><span class="an-act-title">💬 ${x.title || 'Untitled'}</span><span class="an-act-cnt">${x.messages?.length || 0} msgs</span></div>`).join('') || '<div style="color:#555;font-size:13px">No chats yet.</div>'}</div>`;
  }
})();

// ══════════════════════════════════════════════════════════════
// 9. WEATHER & LOCATION
// ══════════════════════════════════════════════════════════════
(function() {
  const WD = {0:'Clear sky',1:'Mainly clear',2:'Partly cloudy',3:'Overcast',45:'Foggy',51:'Light drizzle',53:'Drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',73:'Snow',80:'Showers',95:'Thunderstorm'};
  function wdesc(c) { return WD[c] || 'Unknown'; }
  function wicon(c) { if (c<=1) return '☀️'; if (c<=3) return '⛅'; if (c<=48) return '🌫️'; if (c<=67) return '🌧️'; if (c<=77) return '❄️'; if (c<=82) return '🌦️'; return '⛈️'; }

  function showCard(w) {
    const card = document.getElementById('loc-weather-card'); if (!card) return;
    card.classList.remove('hidden'); card.style.display = 'block';
    card.innerHTML = `<div class="wcard-city">📍 ${w.city}</div><div class="wcard-temp">${wicon(w.code)} ${w.temp}°C</div><div class="wcard-desc">${w.desc}</div><div class="wcard-row"><span>💨 ${w.wind} km/h</span><span>💧 ${w.humidity}%</span></div>`;
  }

  window.openLocation  = function() {
    _showModal('location-modal');
    const st = document.getElementById('loc-status'); if (st) st.textContent = 'Enter city name below.';
    try { const w = JSON.parse(localStorage.getItem('jameeai_weather') || 'null'); if (w) showCard(w); } catch(e) {}
  };
  window.closeLocation = function() { _hideModal('location-modal'); window.updateLocationLabel(); };

  window.fetchWeatherByCity = function() {
    const city = (document.getElementById('loc-city-input')?.value || '').trim();
    if (!city) { if (typeof showToast === 'function') showToast('⚠️ Enter city name.'); return; }
    const st = document.getElementById('loc-status'); if (st) st.textContent = '⏳ Fetching...';
    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`)
      .then(r => r.json()).then(data => {
        const loc = data?.results?.[0]; if (!loc) throw new Error('City not found');
        const name = loc.name + (loc.country ? ', ' + loc.country : '');
        return fetch(`https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current_weather=true&hourly=relativehumidity_2m&timezone=auto`)
          .then(r => r.json()).then(w => ({ w, name }));
      }).then(({ w, name }) => {
        const cw = w.current_weather;
        const wd = { city: name, temp: Math.round(cw.temperature), wind: cw.windspeed, code: cw.weathercode, humidity: w.hourly?.relativehumidity_2m?.[0] || '--', desc: wdesc(cw.weathercode) };
        localStorage.setItem('jameeai_weather', JSON.stringify(wd));
        try { const pk = 'jameeai_profile_' + (typeof currentUser !== 'undefined' ? currentUser : 'guest'); const p = JSON.parse(localStorage.getItem(pk) || '{}'); p.location = name; localStorage.setItem(pk, JSON.stringify(p)); } catch(e) {}
        showCard(wd); if (st) st.textContent = '';
        if (typeof showToast === 'function') showToast('📍 Weather: ' + name);
        window.updateLocationLabel();
      }).catch(err => { if (st) st.textContent = '❌ ' + err.message; if (typeof showToast === 'function') showToast('❌ ' + err.message); });
  };

  window.getWeatherPrompt = function() {
    try { const w = JSON.parse(localStorage.getItem('jameeai_weather') || 'null'); return w ? `User location: ${w.city}, ${w.temp}°C, ${w.desc}.` : ''; } catch(e) { return ''; }
  };
})();

// ══════════════════════════════════════════════════════════════
// 10. PROFILE & MEMORY
// ══════════════════════════════════════════════════════════════
(function() {
  const AC = ['#a78bfa','#10a37f','#f59e0b','#3b82f6','#ef4444','#ec4899','#14b8a6','#f97316','#8b5cf6','#6366f1'];
  function pk() { return 'jameeai_profile_' + (typeof currentUser !== 'undefined' ? currentUser : 'guest'); }
  function sm(o) { try { localStorage.setItem(pk(), JSON.stringify(o)); } catch(e) {} }

  window.getMemory = function() { try { return JSON.parse(localStorage.getItem(pk()) || '{}'); } catch(e) { return {}; } };

  window.openProfile = function() {
    _showModal('profile-modal');
    const mem = window.getMemory();
    ['name','location','favorite_color','favorite_food','age','work'].forEach(f => { const el = document.getElementById('prof-' + f); if (el) el.value = mem[f] || ''; });
    const av = document.getElementById('prof-avatar-preview');
    if (av) { av.textContent = (mem.name || (typeof currentUser !== 'undefined' ? currentUser : 'U'))[0].toUpperCase(); av.style.background = mem.avatarColor || '#a78bfa'; }
    window.renderAvatarSwatches();
  };
  window.closeProfile = function() { _hideModal('profile-modal'); };

  window.saveProfile = function() {
    const mem = window.getMemory();
    ['name','location','favorite_color','favorite_food','age','work'].forEach(f => { const el = document.getElementById('prof-' + f); if (el && el.value.trim()) mem[f] = el.value.trim(); });
    sm(mem);
    const nd = document.getElementById('user-name-display'); if (nd && mem.name) nd.textContent = mem.name;
    const av = document.getElementById('user-avatar'); if (av && mem.name) av.textContent = mem.name[0].toUpperCase(); if (av && mem.avatarColor) av.style.background = mem.avatarColor;
    if (typeof showToast === 'function') showToast('✅ Profile saved!');
    window.updateLocationLabel();
  };

  window.clearMemory = function() { if (!confirm('Clear all memory?')) return; sm({}); window.openProfile(); if (typeof showToast === 'function') showToast('🧠 Cleared.'); };

  window.renderAvatarSwatches = function() {
    const wrap = document.getElementById('prof-avatar-swatches'); if (!wrap) return;
    const mem = window.getMemory();
    wrap.innerHTML = AC.map(c => `<div class="av-color-swatch ${mem.avatarColor === c ? 'selected' : ''}" style="background:${c}" data-color="${c}" data-action="selectAvatar"></div>`).join('');
  };

  window.selectAvatar = function(color) {
    const mem = window.getMemory(); mem.avatarColor = color; sm(mem);
    const av = document.getElementById('prof-avatar-preview'); if (av) av.style.background = color;
    window.renderAvatarSwatches();
  };

  window.getMemoryPrompt = function() {
    const m = window.getMemory(), p = [];
    if (m.name) p.push(`User's name is ${m.name}`);
    if (m.location) p.push(`lives in ${m.location}`);
    if (m.age) p.push(`age ${m.age}`);
    if (m.work) p.push(`works as ${m.work}`);
    if (m.favorite_color) p.push(`favorite color is ${m.favorite_color}`);
    if (m.favorite_food) p.push(`favorite food is ${m.favorite_food}`);
    return p.length > 0 ? 'About user: ' + p.join(', ') + '.' : '';
  };

  window.extractAndStoreMemory = function(text) {
    const mem = window.getMemory(); let ch = false;
    const nm = text.match(/(?:my name is|i am|i'm|call me)\s+([A-Za-z]+)/i); if (nm) { mem.name = nm[1]; ch = true; }
    const am = text.match(/(?:i am|i'm)\s+(\d+)\s+years? old/i); if (am) { mem.age = am[1]; ch = true; }
    const lm = text.match(/(?:i (?:live|am) in|i'm from|from)\s+([A-Za-z ,]+?)(?:\.|,|$)/i); if (lm) { mem.location = lm[1].trim(); ch = true; }
    const jm = text.match(/(?:i work as|i am a|i'm a)\s+([A-Za-z ]+?)(?:\.|,|$)/i); if (jm) { mem.work = jm[1].trim(); ch = true; }
    if (ch) sm(mem);
  };
})();

// ══════════════════════════════════════════════════════════════
// 11. HISTORY BACKUP
// ══════════════════════════════════════════════════════════════
(function() {
  function hk() { return 'jameeai_history_' + (typeof currentUser !== 'undefined' ? currentUser : 'guest'); }
  function gc() { try { return JSON.parse(localStorage.getItem(hk()) || '[]'); } catch(e) { return []; } }
  function dl(blob, name) { const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: name }); document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }
  function stamp() { return new Date().toISOString().slice(0, 10); }

  function renderStats() {
    const el = document.getElementById('hb-stats'); if (!el) return;
    const c = gc(), m = c.reduce((s, x) => s + (x.messages?.length || 0), 0), sz = (JSON.stringify(c).length * 2 / 1024).toFixed(1);
    el.innerHTML = `<span class="hb-stat"><b>${c.length}</b> chats</span><span class="hb-stat"><b>${m}</b> msgs</span><span class="hb-stat"><b>${sz} KB</b></span>`;
  }

  window.openHistoryBackup  = function() { _showModal('history-backup-modal'); renderStats(); };
  window.closeHistoryBackup = function() { _hideModal('history-backup-modal'); };

  window.hbExportJSON = function() {
    const c = gc(); if (!c.length) { if (typeof showToast === 'function') showToast('⚠️ No chats.'); return; }
    dl(new Blob([JSON.stringify({ version: 1, exported: new Date().toISOString(), conversations: c }, null, 2)], { type: 'application/json' }), 'jameeai-backup-' + stamp() + '.json');
    if (typeof showToast === 'function') showToast('✅ JSON backup downloaded!');
  };

  window.hbExportTXT = function() {
    const c = gc(); if (!c.length) { if (typeof showToast === 'function') showToast('⚠️ No chats.'); return; }
    const l = ['Jamee AI Backup', '='.repeat(50), ''];
    c.forEach((x, i) => { l.push(`Chat ${i+1}: ${x.title}`); (x.messages || []).forEach(m => { l.push((m.role === 'user' ? '👤 You' : '🤖 AI') + ':'); l.push(m.content); l.push(''); }); });
    dl(new Blob([l.join('\n')], { type: 'text/plain' }), 'jameeai-backup-' + stamp() + '.txt');
    if (typeof showToast === 'function') showToast('✅ TXT downloaded!');
  };

  window.hbImport = function(e) {
    const file = e.target.files[0]; if (!file) return;
    const r = new FileReader();
    r.onload = function(ev) {
      try {
        const data = JSON.parse(ev.target.result);
        const c = data.conversations || (Array.isArray(data) ? data : null);
        if (!c) throw new Error('Invalid format');
        if (!confirm(`Import ${c.length} chats?`)) return;
        localStorage.setItem(hk(), JSON.stringify(c));
        if (typeof conversations !== 'undefined') {
          conversations.length = 0; c.forEach(x => conversations.push(x));
          if (typeof renderHistory === 'function') renderHistory();
          if (typeof switchConversation === 'function' && c.length > 0) switchConversation(c[0].id);
        }
        renderStats();
        if (typeof showToast === 'function') showToast('✅ ' + c.length + ' chats restored!');
      } catch(err) { if (typeof showToast === 'function') showToast('❌ ' + err.message); }
    };
    r.readAsText(file); e.target.value = '';
  };
})();

// ══════════════════════════════════════════════════════════════
// 12. SHARE CHAT
// ══════════════════════════════════════════════════════════════
window.shareChat = function() {
  const conv = (typeof getActiveConv === 'function') ? getActiveConv() : null;
  const url  = window.location.href;
  if (navigator.share) { navigator.share({ title: 'Jamee AI ' + (conv?.title || ''), url }).catch(() => _doShare(url)); }
  else _doShare(url);
};
function _doShare(url) {
  navigator.clipboard.writeText(url).then(() => {
    if (typeof showToast === 'function') showToast('🔗 Link copied!');
    const btn = document.getElementById('tb-share');
    if (btn) { const o = btn.textContent; btn.textContent = 'Copied!'; btn.style.color = '#10b981'; setTimeout(() => { btn.textContent = o; btn.style.color = ''; }, 2000); }
  }).catch(() => { if (typeof showToast === 'function') showToast('⚠️ Copy failed.'); });
}

// ══════════════════════════════════════════════════════════════
// 13. NLP PROMPT HELPER
// ══════════════════════════════════════════════════════════════
window.getNLPPrompt = function(text) {
  const t = text.toLowerCase();
  if (/\b(joke|funny|laugh)\b/.test(t))   return 'Be witty.';
  if (/\b(sad|depress|lonely|upset)\b/.test(t)) return 'Be empathetic.';
  if (/\b(code|program|debug|error)\b/.test(t)) return 'Be technical and precise.';
  if (/\b(study|learn|explain|teach)\b/.test(t)) return 'Explain clearly step by step.';
  return '';
};

// ══════════════════════════════════════════════════════════════
// 14. LOCATION LABEL UPDATE
// ══════════════════════════════════════════════════════════════
window.updateLocationLabel = function() {
  const mem = (typeof getMemory === 'function') ? getMemory() : {};
  const el  = document.getElementById('tb-location-label');
  if (el) el.textContent = mem.location ? '📍 ' + mem.location.split(',')[0] : 'Set location';
};

// ══════════════════════════════════════════════════════════════
// 15. CHATGPT STYLE OVERRIDE
// ══════════════════════════════════════════════════════════════
(function() {
  const s = document.createElement('style');
  s.textContent = `
    #sidebar { background: #171717 !important; border-right: 1px solid rgba(255,255,255,0.06) !important; }
    #main-content, #chat-messages, .welcome-wrap, .bottom-icon-bar, .input-zone { background: #212121 !important; }
    .top-bar { background: #212121 !important; border-bottom: 1px solid rgba(255,255,255,0.05) !important; }
    #welcome-title { font-size: 28px !important; font-weight: 600 !important; color: #ececec !important; }
    .w-chip { background: rgba(255,255,255,0.05) !important; border: 1px solid rgba(255,255,255,0.1) !important; border-radius: 12px !important; color: #c5c5d2 !important; font-size: 13px !important; }
    .w-chip:hover { background: rgba(255,255,255,0.09) !important; color: #fff !important; transform: none !important; }
    .msg-row.ai  { padding: 12px 10% 16px 10% !important; }
    .msg-row.user { padding: 6px 10% !important; }
    .msg-row.user .msg-bubble { background: #2f2f2f !important; border-radius: 18px !important; max-width: 70% !important; }
    .msg-row.ai .msg-text { font-size: 15px !important; line-height: 1.8 !important; color: #ececec !important; }
    .input-box { background: #2f2f2f !important; border: 1px solid rgba(255,255,255,0.1) !important; border-radius: 16px !important; max-width: 760px !important; margin: 0 auto !important; }
    #chat-input { font-size: 15px !important; color: #ececec !important; }
    #chat-input::placeholder { color: #6e6e80 !important; }
    .send-btn { background: #fff !important; color: #000 !important; }
    .send-btn:disabled { background: rgba(255,255,255,0.15) !important; color: rgba(255,255,255,0.3) !important; }
    .modal-card { background: #2f2f2f !important; border: 1px solid rgba(255,255,255,0.1) !important; }
    .msg-text pre, .code-card { background: #171717 !important; }
    .code-card-header { background: #212121 !important; }
    .sb-footer { background: transparent !important; border-top: 1px solid rgba(255,255,255,0.06) !important; }
    .bottom-icon-bar { border-top: 1px solid rgba(255,255,255,0.05) !important; }
    @media(max-width:900px) { .msg-row.ai,.msg-row.user { padding-left:5% !important; padding-right:5% !important; } .input-zone { padding-left:5% !important; padding-right:5% !important; } }
    @media(max-width:600px) { .msg-row.ai,.msg-row.user { padding-left:16px !important; padding-right:16px !important; } .input-zone { padding:10px 12px 14px !important; } #welcome-title { font-size:22px !important; } }
  `;
  document.head.appendChild(s);
})();

// ══════════════════════════════════════════════════════════════
// 16. GLOBAL INIT — runs after page load
// ══════════════════════════════════════════════════════════════
window.addEventListener('load', function() {
  // Location label
  window.updateLocationLabel();

  // Avatar swatches
  if (typeof renderAvatarSwatches === 'function') renderAvatarSwatches();

  // Sound button state
  const soundBtn = document.getElementById('sound-toggle-btn');
  const soundOn  = localStorage.getItem('jameeai_sound') !== 'off';
  if (soundBtn) soundBtn.style.opacity = soundOn ? '1' : '0.4';

  // Voice output button state
  const voBtn = document.getElementById('voice-out-btn');
  if (voBtn && localStorage.getItem('jameeai_voice_out') === 'on') voBtn.style.color = '#10b981';

  // History modal button
  const hb = document.getElementById('history-modal-btn');
  if (hb) hb.addEventListener('click', function(e) {
    e.stopPropagation();
    if (typeof openHistoryModal === 'function') openHistoryModal();
    else { const m = document.getElementById('history-modal'); if (m) m.classList.remove('hidden'); }
  });

  // Logout button
  const lb = document.getElementById('logout-btn');
  if (lb) lb.addEventListener('click', function(e) {
    e.stopPropagation();
    ['login-username','login-password'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    document.getElementById('login-screen')?.classList.remove('hidden');
    document.getElementById('register-screen')?.classList.add('hidden');
    document.getElementById('chatbox-screen')?.classList.add('hidden');
    if (typeof showToast === 'function') showToast('👋 Signed out');
  });

  // data-action delegation for dynamic elements (admin table buttons etc.)
  document.addEventListener('click', function(e) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const a = btn.dataset.action;
    if (a === 'adminToggleRole') { adminToggleRole && adminToggleRole(btn.dataset.user); }
    if (a === 'adminDeleteUser') { adminDeleteUser && adminDeleteUser(btn.dataset.user); }
    if (a === 'kbDelete')        { kbDelete        && kbDelete(parseInt(btn.dataset.idx)); }
    if (a === 'selectAvatar')    { selectAvatar    && selectAvatar(btn.dataset.color); }
  });

  console.log('✅ AllModules.js — All 16 modules loaded!');
});