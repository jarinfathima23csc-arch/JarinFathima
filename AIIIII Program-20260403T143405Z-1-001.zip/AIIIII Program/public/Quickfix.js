// ============================================================
// QuickFix.js — Fix all non-working buttons
// Add this LAST in index.html before </body>
// <script src="QuickFix.js"></script>
// ============================================================

// ── 1. sendChip fix (welcome chips were broken) ─────────────
window.sendChip = function(text) {
  const ta = document.getElementById('chat-input');
  const sb = document.getElementById('send-message');
  if (ta && sb) {
    ta.value = text;
    ta.dispatchEvent(new Event('input'));
    sb.click();
  }
};

// ── 2. Wait for DOM + all scripts to finish ─────────────────
window.addEventListener('load', function () {

  // ── TOP BAR BUTTONS ──────────────────────────────────────

  // Voice output button
  const voiceOutBtn = document.getElementById('voice-out-btn');
  if (voiceOutBtn) voiceOutBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleVoiceOutput === 'function') toggleVoiceOutput();
  };

  // Set Location button
  const locationBtn = document.getElementById('tb-location-btn');
  if (locationBtn) locationBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof openLocation === 'function') openLocation();
  };

  // Notification / Sound button (top bar)
  const notifBtn = document.getElementById('tb-notif-btn');
  if (notifBtn) notifBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleSound === 'function') toggleSound();
  };

  // Theme toggle button
  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) themeBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleTheme === 'function') toggleTheme();
  };

  // Share button
  const shareBtn = document.getElementById('tb-share');
  if (shareBtn) shareBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof shareChat === 'function') shareChat();
  };

  // Language button
  const langBtn = document.getElementById('lang-btn');
  const langDD  = document.getElementById('lang-dropdown');
  if (langBtn && langDD) {
    langBtn.onclick = function(e) {
      e.stopPropagation();
      langDD.classList.toggle('hidden');
    };
  }

  // ── SIDEBAR FOOTER BUTTONS ───────────────────────────────

  // Sound toggle (sidebar footer)
  const soundBtn = document.getElementById('sound-toggle-btn');
  if (soundBtn) soundBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleSound === 'function') toggleSound();
  };

  // History modal button (clock icon)
  const histBtn = document.getElementById('history-modal-btn');
  if (histBtn) histBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof openHistoryModal === 'function') openHistoryModal();
  };

  // Admin button
  const adminBtn = document.getElementById('admin-btn');
  if (adminBtn) adminBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof openAdminPanel === 'function') openAdminPanel();
  };

  // ── SIDEBAR TOOLS BUTTONS ────────────────────────────────

  document.querySelectorAll('.sb-mod-btn').forEach(function(btn) {
    btn.onclick = function(e) {
      e.stopPropagation();
      const action = btn.dataset.action;
      const actions = {
        openKB:            function() { if (typeof openKB            === 'function') openKB(); },
        openAnalytics:     function() { if (typeof openAnalytics     === 'function') openAnalytics(); },
        openLocation:      function() { if (typeof openLocation      === 'function') openLocation(); },
        openProfile:       function() { if (typeof openProfile       === 'function') openProfile(); },
        openHistoryBackup: function() { if (typeof openHistoryBackup === 'function') openHistoryBackup(); },
      };
      if (actions[action]) actions[action]();
    };
  });

  // ── SIDEBAR MODE BUTTONS (Chat / Code / Image) ───────────

  document.querySelectorAll('.sb-mode-btn').forEach(function(btn) {
    btn.onclick = function(e) {
      e.stopPropagation();
      if (typeof setMode === 'function') setMode(btn.dataset.mode);
    };
  });

  // ── BOTTOM ICON BAR ──────────────────────────────────────

  document.querySelectorAll('.bib-btn').forEach(function(btn) {
    btn.onclick = function(e) {
      e.stopPropagation();
      const action = btn.dataset.action;
      const actions = {
        openKB:            function() { if (typeof openKB            === 'function') openKB(); },
        openHistoryBackup: function() { if (typeof openHistoryBackup === 'function') openHistoryBackup(); },
        openLocation:      function() { if (typeof openLocation      === 'function') openLocation(); },
        openAnalytics:     function() { if (typeof openAnalytics     === 'function') openAnalytics(); },
        openProfile:       function() { if (typeof openProfile       === 'function') openProfile(); },
      };
      if (actions[action]) actions[action]();
    };
  });

  // ── VOICE / MIC BUTTON (input box) ──────────────────────

  const voiceBtn = document.getElementById('voice-btn');
  if (voiceBtn) voiceBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleVoiceInput === 'function') toggleVoiceInput();
  };

  // ── MENU / SIDEBAR TOGGLE ────────────────────────────────

  const menuBtn = document.getElementById('menu-btn');
  if (menuBtn) menuBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleSidebar === 'function') toggleSidebar();
  };

  const sbToggle = document.getElementById('sidebar-toggle');
  if (sbToggle) sbToggle.onclick = function(e) {
    e.stopPropagation();
    if (typeof toggleSidebar === 'function') toggleSidebar();
  };

  // ── MODAL CLOSE BUTTONS ──────────────────────────────────

  document.querySelectorAll('.modal-close-btn').forEach(function(btn) {
    btn.onclick = function(e) {
      e.stopPropagation();
      const action = btn.dataset.action;
      const closes = {
        closeKB:            function() { if (typeof closeKB            === 'function') closeKB(); },
        closeProfile:       function() { if (typeof closeProfile       === 'function') closeProfile(); },
        closeLocation:      function() { if (typeof closeLocation      === 'function') closeLocation(); },
        closeAnalytics:     function() { if (typeof closeAnalytics     === 'function') closeAnalytics(); },
        closeAdminPanel:    function() { if (typeof closeAdminPanel    === 'function') closeAdminPanel(); },
        closeHistoryBackup: function() { if (typeof closeHistoryBackup === 'function') closeHistoryBackup(); },
        closeExportModal:   function() { if (typeof closeExportModal   === 'function') closeExportModal(); },
      };
      if (closes[action]) closes[action]();
      // fallback: hide the closest modal overlay
      const overlay = btn.closest('.modal-overlay, .hm-overlay');
      if (overlay) {
        overlay.classList.add('hidden');
        overlay.style.display = 'none';
      }
    };
  });

  // ── PROFILE SAVE / CLEAR MEMORY ─────────────────────────

  const saveProfileBtn = document.querySelector('[data-action="saveProfile"]');
  if (saveProfileBtn) saveProfileBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof saveProfile === 'function') saveProfile();
    if (typeof renderAvatarSwatches === 'function') renderAvatarSwatches();
  };

  const clearMemBtn = document.querySelector('[data-action="clearMemory"]');
  if (clearMemBtn) clearMemBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof clearMemory === 'function') clearMemory();
  };

  // ── WEATHER FETCH ─────────────────────────────────────────

  const weatherBtn = document.querySelector('[data-action="fetchWeatherByCity"]');
  if (weatherBtn) weatherBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof fetchWeatherByCity === 'function') fetchWeatherByCity();
  };

  // ── KB ADD ───────────────────────────────────────────────

  const kbAddBtn = document.querySelector('[data-action="kbAdd"]');
  if (kbAddBtn) kbAddBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof kbAdd === 'function') kbAdd();
  };

  // ── ADMIN ADD USER ───────────────────────────────────────

  const adminAddBtn = document.querySelector('[data-action="adminAddUser"]');
  if (adminAddBtn) adminAddBtn.onclick = function(e) {
    e.stopPropagation();
    if (typeof adminAddUser === 'function') adminAddUser();
  };

  // ── WELCOME CHIPS (dynamic ones created by clearChatUI) ──

  document.addEventListener('click', function(e) {
    const chip = e.target.closest('.w-chip');
    if (!chip) return;
    const text = chip.dataset.chip || chip.getAttribute('onclick');
    if (chip.dataset.chip) {
      window.sendChip(chip.dataset.chip);
    }
  });

  // ── SIDEBAR USER FOOTER → open profile ──────────────────

  const sbUser = document.querySelector('.sb-user[data-action="openProfile"]');
  if (sbUser) sbUser.onclick = function(e) {
    e.stopPropagation();
    if (typeof openProfile === 'function') openProfile();
  };

  // ── HB EXPORT / BACKUP BUTTONS ──────────────────────────

  const hbJSON = document.querySelector('[data-action="hbExportJSON"]');
  if (hbJSON) hbJSON.onclick = function(e) {
    e.stopPropagation();
    if (typeof hbExportJSON === 'function') hbExportJSON();
  };

  const hbTXT = document.querySelector('[data-action="hbExportTXT"]');
  if (hbTXT) hbTXT.onclick = function(e) {
    e.stopPropagation();
    if (typeof hbExportTXT === 'function') hbExportTXT();
  };

  // ── CSS FIX: remove any invisible overlay blocking clicks ─

  const style = document.createElement('style');
  style.textContent = `
    /* Ensure login/register screens never block chatbox clicks */
    #login-screen.hidden,
    #register-screen.hidden {
      display: none !important;
      pointer-events: none !important;
      visibility: hidden !important;
    }

    /* Sidebar overlay must not block when not shown */
    #sidebar-overlay:not(.show) {
      display: none !important;
      pointer-events: none !important;
    }

    /* All interactive buttons must be clickable */
    .sb-mod-btn,
    .sb-mode-btn,
    .bib-btn,
    .tb-icon-btn,
    .tb-pill-btn,
    .tb-text-btn,
    .sb-icon-btn,
    .voice-btn,
    .send-btn,
    .attach-btn,
    #menu-btn,
    #voice-btn,
    #send-message,
    #voice-out-btn,
    #tb-location-btn,
    #tb-notif-btn,
    #theme-toggle-btn,
    #lang-btn,
    #tb-share,
    #sound-toggle-btn,
    #history-modal-btn,
    #admin-btn,
    #logout-btn,
    .modal-close-btn,
    .hm-close-btn,
    .w-chip {
      pointer-events: auto !important;
      cursor: pointer !important;
      position: relative !important;
      z-index: 100 !important;
    }

    /* Modal overlays sit above everything */
    .modal-overlay:not(.hidden),
    .hm-overlay:not(.hidden) {
      z-index: 9999 !important;
      pointer-events: auto !important;
    }
  `;
  document.head.appendChild(style);

  console.log('✅ QuickFix.js loaded — all buttons fixed!');
});