// ============================================================
// Chatbotreply.js — AI Chat, Code Gen, Image Gen, File Upload
// ============================================================

const chatInput      = document.getElementById('chat-input');
const sendBtn        = document.getElementById('send-message');
const fileUpload     = document.getElementById('file-upload');
const filePreviewBar = document.getElementById('file-preview-bar');
const filePreviews   = document.getElementById('file-previews');
const clearFilesBtn  = document.getElementById('clear-files-btn');

let currentMode  = 'chat';
let pendingFiles = [];

// ══════════════════════════════════════════════════════════════
// AUTO-RESIZE TEXTAREA
// ══════════════════════════════════════════════════════════════
chatInput.addEventListener('input', () => {
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 180) + 'px';
  sendBtn.disabled = !chatInput.value.trim() && pendingFiles.length === 0;
});

chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
});

// ══════════════════════════════════════════════════════════════
// MODE SWITCHER
// ══════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════
// MODE SWITCHER — syncs sidebar buttons + input pills
// ══════════════════════════════════════════════════════════════
function setMode(mode) {
  currentMode = mode;
  const map = { chat:'Ask anything…', code:'Describe the code you want…', image:'Describe your image in detail…' };
  chatInput.placeholder = map[mode] || 'Ask anything…';

  // Sync input box pills
  document.querySelectorAll('.mode-pill').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
  // Sync sidebar buttons
  document.querySelectorAll('.sb-mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
  chatInput.focus();
}

// Input box pills
document.querySelectorAll('.mode-pill').forEach(btn => {
  btn.addEventListener('click', () => setMode(btn.dataset.mode));
});

// Sidebar mode buttons
document.querySelectorAll('.sb-mode-btn').forEach(btn => {
  btn.addEventListener('click', () => setMode(btn.dataset.mode));
});

// ══════════════════════════════════════════════════════════════
// FILE UPLOAD
// ══════════════════════════════════════════════════════════════
fileUpload.addEventListener('change', async () => {
  for (const file of Array.from(fileUpload.files)) {
    const isImg  = file.type.startsWith('image/');
    const dataUrl = await readAsDataURL(file);
    const content = isImg ? null : await readAsText(file).catch(() => null);
    pendingFiles.push({ name: file.name, type: isImg ? 'image' : 'file', dataUrl, content });
  }
  fileUpload.value = '';
  updateFilePreviews();
  sendBtn.disabled = false;
});

function readAsDataURL(f) {
  return new Promise((res,rej) => { const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(f); });
}
function readAsText(f) {
  return new Promise((res,rej) => { const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsText(f); });
}

function updateFilePreviews() {
  filePreviews.innerHTML = '';
  if (pendingFiles.length === 0) { filePreviewBar.classList.add('hidden'); return; }
  filePreviewBar.classList.remove('hidden');
  pendingFiles.forEach(f => {
    if (f.type === 'image') {
      const img = document.createElement('img');
      img.src = f.dataUrl; img.className = 'fp-img'; img.title = f.name;
      filePreviews.appendChild(img);
    } else {
      const d = document.createElement('div');
      d.className = 'fp-file';
      d.innerHTML = `<span>${fileIconOf(f.name)}</span><span>${escH(f.name)}</span>`;
      filePreviews.appendChild(d);
    }
  });
}

clearFilesBtn.addEventListener('click', () => {
  pendingFiles = []; updateFilePreviews();
  if (!chatInput.value.trim()) sendBtn.disabled = true;
});

// ══════════════════════════════════════════════════════════════
// TYPING INDICATOR
// ══════════════════════════════════════════════════════════════
function showTyping() {
  const w = document.getElementById('welcome-state');
  if (w) w.style.display = 'none';

  const msgs = document.getElementById('chat-messages');
  const row  = document.createElement('div');
  row.className = 'msg-row ai'; row.id = 'typing-row';
  row.innerHTML = `
    <div class="msg-body">
      <div style="display:flex;flex-direction:row;gap:6px;align-items:center;padding:12px 4px 8px 4px;">
        <span style="display:block;width:9px;height:9px;border-radius:50%;background:#aaa;animation:dotBounce 1.2s ease-in-out infinite;animation-delay:0s;"></span>
        <span style="display:block;width:9px;height:9px;border-radius:50%;background:#aaa;animation:dotBounce 1.2s ease-in-out infinite;animation-delay:0.2s;"></span>
        <span style="display:block;width:9px;height:9px;border-radius:50%;background:#aaa;animation:dotBounce 1.2s ease-in-out infinite;animation-delay:0.4s;"></span>
      </div>
    </div>`;
  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;
}

function hideTyping() {
  const el = document.getElementById('typing-row');
  if (el) el.remove();
}

// ══════════════════════════════════════════════════════════════
// CODE DISPLAY
// ══════════════════════════════════════════════════════════════
function displayCode(lang, code, explanation) {
  const msgs = document.getElementById('chat-messages');
  const row  = document.createElement('div');
  row.className = 'msg-row ai';

  let expHtml = '';
  if (explanation) {
    try { expHtml = (typeof marked !== 'undefined') ? marked.parse(explanation) : explanation; } catch(e) { expHtml = explanation; }
  }

  row.innerHTML = `
    <div class="msg-avatar ai-av">
      <svg width="14" height="14" viewBox="0 0 28 28" fill="none"><path d="M14 8L20 11V17L14 20L8 17V11L14 8Z" fill="white"/></svg>
    </div>
    <div class="msg-body">
      <div class="msg-bubble"><div class="msg-text">
          <div class="tag tag-code">
            <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><path d="M3 4L1 6L3 8M9 4L11 6L9 8M6.5 3L5.5 9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
            ${escH(lang || 'code')}
          </div>
          ${expHtml ? `<div class="code-explanation">${expHtml}</div>` : ''}
          <div class="code-card">
            <div class="code-card-header">
              <span class="code-lang">${escH(lang || 'code')}</span>
              <button class="copy-btn" onclick="copyCode(this)">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="4" y="4" width="7" height="7" rx="1" stroke="currentColor" stroke-width="1.2"/><path d="M4 4V3a1 1 0 00-1-1H3a1 1 0 00-1 1v5a1 1 0 001 1h1" stroke="currentColor" stroke-width="1.2"/></svg>
                Copy
              </button>
            </div>
            <pre>${escH(code || '')}</pre>
          </div>
        </div>
      </div>
    </div>`;

  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;

  const conv = (typeof getActiveConv !== 'undefined') ? getActiveConv() : null;
  if (conv) conv.messages.push({ role:'ai', content:`\`\`\`${lang}\n${code}\n\`\`\`\n\n${explanation||''}`, attachments:[] });
}

// ══════════════════════════════════════════════════════════════
// IMAGE DISPLAY
// ══════════════════════════════════════════════════════════════
function displayImage(prompt, url) {
  const msgs = document.getElementById('chat-messages');
  const row  = document.createElement('div');
  row.className = 'msg-row ai';
  row.innerHTML = `
    <div class="msg-avatar ai-av">
      <svg width="14" height="14" viewBox="0 0 28 28" fill="none"><path d="M14 8L20 11V17L14 20L8 17V11L14 8Z" fill="white"/></svg>
    </div>
    <div class="msg-body">
      <div class="msg-bubble"><div class="msg-text">
          <div class="tag tag-image">
            <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><rect x="1" y="2" width="10" height="8" rx="1.5" stroke="currentColor" stroke-width="1.2"/><circle cx="4" cy="5" r="1" fill="currentColor"/><path d="M1 8L4 5.5L6.5 7.5L8.5 5.5L11 8" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>
            Image
          </div>
          <p class="img-prompt-label">"${escH(prompt)}"</p>
          <div class="img-card">
            <div class="img-frame">
              <img src="${url}" alt="${escH(prompt)}" loading="lazy"
                onerror="this.closest('.img-frame').innerHTML='<p style=padding:14px;color:#ef4444>⚠️ Image failed to load.</p>'">
            </div>
            <div class="img-btns">
              <button class="img-btn" onclick="window.open('${url}','_blank')">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M7 2h3v3M10 2L6 6M5 3H3a1 1 0 00-1 1v5a1 1 0 001 1h5a1 1 0 001-1V7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                Open
              </button>
              <button class="img-btn" onclick="dlImg('${url}')">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 2v6M3 6l3 3 3-3M2 10h8" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                Download
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;

  const conv = (typeof getActiveConv !== 'undefined') ? getActiveConv() : null;
  if (conv) conv.messages.push({ role:'ai', content:`[Image: ${prompt}]`, attachments:[] });
}

// ══════════════════════════════════════════════════════════════
// GLOBAL UTILS
// ══════════════════════════════════════════════════════════════
window.copyCode = function(btn) {
  const pre = btn.closest('.code-card').querySelector('pre');
  navigator.clipboard.writeText(pre.textContent).then(() => {
    btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg> Copied!`;
    setTimeout(() => btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="4" y="4" width="7" height="7" rx="1" stroke="currentColor" stroke-width="1.2"/><path d="M4 4V3a1 1 0 00-1-1H3a1 1 0 00-1 1v5a1 1 0 001 1h1" stroke="currentColor" stroke-width="1.2"/></svg> Copy`, 2000);
  });
};
window.dlImg = function(url) {
  const a = document.createElement('a');
  a.href = url; a.download = 'jameeai-image.png'; a.target = '_blank';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
};
function escH(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fileIconOf(name) {
  const ext = (name.split('.').pop()||'').toLowerCase();
  return ({pdf:'📄',txt:'📝',doc:'📝',docx:'📝',js:'⚡',py:'🐍',html:'🌐',css:'🎨',json:'📋',csv:'📊',md:'📝'})[ext]||'📁';
}

// ══════════════════════════════════════════════════════════════
// CODE GENERATION
// ══════════════════════════════════════════════════════════════
async function generateCode(prompt) {
  const sys = `You are an expert programmer. User wants: "${prompt}"
IMPORTANT: Reply ONLY with valid JSON, no markdown fences, no extra text:
{"language":"language_name","code":"complete working code here","explanation":"brief explanation"}`;

  try {
    const r = await fetch('/apicall', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ message: sys })
    });
    if (!r.ok) throw new Error('backend');
    const d = await r.json();
    if (d.error) throw new Error(d.error);
    const m = (d.answer||'').match(/\{[\s\S]*\}/);
    if (m) return JSON.parse(m[0]);
    throw new Error('no json');
  } catch(e) { console.warn('Code backend:', e.message); }

  if (typeof puter !== 'undefined' && puter?.ai?.chat) {
    const r    = await puter.ai.chat(sys);
    const text = typeof r==='string' ? r : (r?.message?.content ? (typeof r.message.content==='string' ? r.message.content : r.message.content.map(x=>x?.text||'').join('')) : '');
    const m    = text.match(/\{[\s\S]*\}/);
    if (m) return JSON.parse(m[0]);
    return { language:'code', code:text, explanation:'Here is the generated code.' };
  }
  throw new Error('Code generation unavailable.');
}

// ══════════════════════════════════════════════════════════════
// IMAGE GENERATION
// ══════════════════════════════════════════════════════════════
async function generateImage(prompt) {
  const seed = Math.floor(Math.random()*99999);
  const enc  = encodeURIComponent(prompt);
  const urls = [
    `https://image.pollinations.ai/prompt/${enc}?width=512&height=512&seed=${seed}&nologo=true`,
    `https://image.pollinations.ai/prompt/${enc}?seed=${seed}`
  ];
  for (const u of urls) { if (await testImg(u)) return u; }
  if (typeof puter !== 'undefined' && puter?.ai?.txt2img) {
    const r = await puter.ai.txt2img(prompt);
    if (r?.src||r?.url) return r.src||r.url;
  }
  throw new Error('Image generation failed. Check your internet connection.');
}

function testImg(url) {
  return new Promise(resolve => {
    const img = new Image();
    const t   = setTimeout(() => resolve(false), 15000);
    img.onload  = () => { clearTimeout(t); resolve(true); };
    img.onerror = () => { clearTimeout(t); resolve(false); };
    img.src = url;
  });
}

// ══════════════════════════════════════════════════════════════
// BACKEND / PUTER
// ══════════════════════════════════════════════════════════════
async function callBackend(msg) {
  const r = await fetch('/apicall', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ message: msg })
  });
  if (!r.ok) { const e = await r.json().catch(()=>({})); throw new Error(e.error || 'Server error'); }
  const d = await r.json();
  if (d.error) throw new Error(d.error);
  if (!d.answer) throw new Error('Empty response from AI');
  return d.answer;
}

async function callPuter(msg) {
  // Wait up to 15 seconds for Puter to load (free, needs time)
  let attempts = 0;
  while ((typeof puter === 'undefined' || !puter?.ai?.chat) && attempts < 50) {
    await new Promise(r => setTimeout(r, 300));
    attempts++;
  }
  if (typeof puter === 'undefined' || !puter?.ai?.chat) {
    throw new Error('Puter not loaded yet');
  }

  try {
    const r = await puter.ai.chat(msg, { model: 'gpt-4o-mini' });
    if (typeof r === 'string' && r.trim()) return r;
    if (r?.message?.content) {
      const content = r.message.content;
      if (typeof content === 'string' && content.trim()) return content;
      if (Array.isArray(content)) return content.map(x => x?.text || '').join('').trim();
    }
    if (r?.text && r.text.trim())    return r.text;
    if (r?.content && r.content.trim()) return r.content;
    throw new Error('Empty response from Puter');
  } catch(puterErr) {
    throw new Error('Puter error: ' + puterErr.message);
  }
}

async function callPollinations(msg) {
  // Goes through our local server (no CORS issues!)
  const r = await fetch('/apicall', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: msg })
  });
  if (!r.ok) throw new Error('Server HTTP ' + r.status);
  const d = await r.json();
  if (d.error) throw new Error(d.error);
  if (!d.answer || !d.answer.trim()) throw new Error('Empty response');
  return d.answer;
}

// ── Claude API fallback (always works) ───────────────────────
async function callClaude(msg) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages:   [{ role: 'user', content: msg }]
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || 'Claude error');
  const text = data?.content?.find(b => b.type === 'text')?.text;
  if (!text) throw new Error('Empty Claude response');
  return text;
}

// ── Auto-detect language ────────────────────────────────────
function detectLang(text) {
  const t = text.slice(0, 200);
  if (/[\u0B80-\u0BFF]/.test(t)) return 'ta';
  if (/[\u0900-\u097F]/.test(t)) return 'hi';
  if (/[\u0600-\u06FF]/.test(t)) return 'ar';
  if (/[\u4E00-\u9FFF]/.test(t)) return 'zh';
  if (/[\u3040-\u30FF]/.test(t)) return 'ja';
  if (/[\uAC00-\uD7AF]/.test(t)) return 'ko';
  if (/[\u0D00-\u0D7F]/.test(t)) return 'ml';
  if (/[\u0C00-\u0C7F]/.test(t)) return 'te';
  if (/[\u0400-\u04FF]/.test(t)) return 'ru';
  return null;
}

const AUTO_LANG_PROMPTS = {
  ta: 'எப்பொழுதும் தமிழிலேயே பதில் சொல்லவும். தமிழ் மட்டும் பயன்படுத்தவும்.',
  hi: 'हमेशा केवल हिंदी में जवाब दें।',
  ar: 'أجب دائماً باللغة العربية فقط.',
  zh: '请始终只用中文回答。',
  ja: '常に日本語のみで回答してください。',
  ko: '항상 한국어로만 대답하세요.',
  ml: 'എപ്പോഴും മലയാളത്തിൽ മാത്രം മറുപടി നൽകുക.',
  te: 'ఎల్లప్పుడూ తెలుగులో మాత్రమే సమాధానం ఇవ్వండి.',
  ru: 'Всегда отвечай только на русском языке.',
};

function buildPrompt(userText, files) {
  // Inject NLP context
  const nlpCtx   = (typeof window.getNLPPrompt === 'function') ? window.getNLPPrompt(userText) : '';
  // Inject emotion context if detected
  const emotionCtx = (typeof window.getEmotionPrompt === 'function') ? window.getEmotionPrompt() : '';
  let langInstr = (typeof window.getLanguagePrompt === 'function') ? window.getLanguagePrompt() : '';
  // Inject memory context
  const memCtx = (typeof window.getMemoryPrompt === 'function') ? window.getMemoryPrompt() : '';
  // Inject weather/location context
  const weatherCtx = (typeof window.getWeatherPrompt === 'function') ? window.getWeatherPrompt() : '';
  // Auto-extract memory from user message
  if (typeof window.extractAndStoreMemory === 'function') window.extractAndStoreMemory(userText);

  // Auto-detect if no manual lang set
  if (!langInstr) {
    const detected = detectLang(userText);
    if (detected) {
      langInstr = AUTO_LANG_PROMPTS[detected] || '';
      const names = {ta:'தமிழ்',hi:'हिंदी',ar:'العربية',zh:'中文',ja:'日本語',ko:'한국어',ml:'മലയാളം',te:'తెలుగు',ru:'Русский'};
      if (!window._lastDetected || window._lastDetected !== detected) {
        window._lastDetected = detected;
        if (typeof showToast === 'function') showToast('🌐 Auto: ' + (names[detected] || detected));
      }
    }
  }

  const emotionInstr = emotionCtx || '';
  const linkInstr = 'You are Jamee AI. When a user asks for links, URLs, YouTube videos, Google results, GitHub repos, or any web resources — always provide them directly as markdown links. You CAN provide links. Format: [title](url). Never say you cannot browse the internet when providing search/resource links.';
  const systemParts  = [linkInstr, memCtx, weatherCtx, nlpCtx, langInstr, emotionInstr].filter(Boolean).join(' ');
  const prefix = `[SYSTEM INSTRUCTION: ${systemParts}]\n\n`;

  if (!files || files.length === 0) return prefix + userText;
  let ctx = prefix + userText + '\n\n';
  files.forEach(f => {
    if (f.type === 'image') ctx += `[Attached image: ${f.name}]\n`;
    else if (f.content) ctx += `[File: ${f.name}]\n${f.content.slice(0,2000)}${f.content.length>2000?'\n...(truncated)':''}\n\n`;
    else ctx += `[Attached file: ${f.name}]\n`;
  });
  return ctx;
}


// ══════════════════════════════════════════════════════════════
// SOURCES — fetch relevant links from Google, YouTube, GitHub, Wikipedia
// ══════════════════════════════════════════════════════════════
async function fetchSources(query) {
  // Wikipedia only — used for auto-attach after AI replies
  try {
    const enc = encodeURIComponent(query.slice(0, 100));
    const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${enc}&limit=2&format=json&origin=*`;
    const res = await fetch(url);
    const [, titles, , links] = await res.json();
    return titles
      .map((t, i) => links[i] ? { title: t, url: links[i] } : null)
      .filter(Boolean);
  } catch(e) { return []; }
}

// Full multi-source fetch — used by /sources command
async function fetchAllSources(query) {
  const enc = encodeURIComponent(query.slice(0, 120));
  const results = [];

  // ── Google Search (top result via search suggestion) ─────────
  results.push({
    platform: 'google',
    icon: '🔍',
    title: `Google: "${query.slice(0, 60)}"`,
    url: `https://www.google.com/search?q=${enc}`,
    desc: 'Search Google for the latest results'
  });

  // ── YouTube ───────────────────────────────────────────────────
  results.push({
    platform: 'youtube',
    icon: '▶️',
    title: `YouTube: "${query.slice(0, 60)}"`,
    url: `https://www.youtube.com/results?search_query=${enc}`,
    desc: 'Find video tutorials and explanations'
  });

  // ── GitHub ────────────────────────────────────────────────────
  results.push({
    platform: 'github',
    icon: '🐙',
    title: `GitHub repos: "${query.slice(0, 60)}"`,
    url: `https://github.com/search?q=${enc}&type=repositories`,
    desc: 'Browse open source code and projects'
  });

  // ── Wikipedia (live API) ──────────────────────────────────────
  try {
    const wikiUrl = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${enc}&limit=3&format=json&origin=*`;
    const res  = await fetch(wikiUrl);
    const [, titles, descs, links] = await res.json();
    titles.forEach((t, i) => {
      if (t && links[i]) {
        results.push({
          platform: 'wikipedia',
          icon: '📖',
          title: t,
          url: links[i],
          desc: descs[i] || 'Wikipedia article'
        });
      }
    });
  } catch(e) { /* Wikipedia unavailable, skip */ }

  return results;
}

// Renders the full /sources response card in chat
window.fetchAndShowSources = async function(query) {
  const sources = await fetchAllSources(query);
  if (!sources || sources.length === 0) {
    if (typeof renderMessage === 'function')
      renderMessage('ai', '❌ Could not fetch sources. Check your connection.', [], false);
    return;
  }

  const msgs = document.getElementById('chat-messages');
  // Remove the "Searching…" message (last AI row)
  const rows = msgs.querySelectorAll('.msg-row.ai');
  if (rows.length > 0) rows[rows.length - 1].remove();

  // Platform colour map
  const colors = {
    google:    '#4285F4',
    youtube:   '#FF0000',
    github:    '#6e40c9',
    wikipedia: '#3366cc'
  };
  const labels = {
    google: 'Google', youtube: 'YouTube', github: 'GitHub', wikipedia: 'Wikipedia'
  };

  const row = document.createElement('div');
  row.className = 'msg-row ai';
  row.innerHTML = `
    <div class="msg-body">
      <div class="msg-bubble">
        <div class="msg-text">
          <div style="font-weight:600;margin-bottom:12px;font-size:14px;">
            🔗 Sources for: <span style="color:#a78bfa">"${escH(query.slice(0,80))}"</span>
          </div>
          <div class="src-grid">
            ${sources.map(s => `
              <a class="src-card" href="${escH(s.url)}" target="_blank" rel="noopener noreferrer">
                <div class="src-card-top">
                  <span class="src-badge" style="background:${colors[s.platform]||'#555'}">${labels[s.platform]||s.platform}</span>
                  <span class="src-icon">${s.icon}</span>
                </div>
                <div class="src-card-title">${escH(s.title)}</div>
                <div class="src-card-desc">${escH(s.desc||'')}</div>
                <div class="src-card-url">${escH(s.url.replace(/^https?:\/\//,'').slice(0,50))}…</div>
              </a>
            `).join('')}
          </div>
          <p style="font-size:11px;color:#666;margin-top:10px;">💡 Type <code>/sources</code> anytime after a question to get links.</p>
        </div>
      </div>
    </div>`;
  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;

  // Save to conversation
  const conv = (typeof getActiveConv !== 'undefined') ? getActiveConv() : null;
  if (conv) conv.messages.push({ role:'ai', content:`[Sources for: ${query}]`, attachments:[] });
};

function renderSources(sources, container) {
  if (!sources || sources.length === 0) return;
  const box = document.createElement('div');
  box.className = 'sources-box';
  box.innerHTML = `
    <div class="sources-label">
      <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
        <circle cx="7" cy="7" r="5.5" stroke="currentColor" stroke-width="1.3"/>
        <path d="M5 5.5C5 4.4 5.9 3.5 7 3.5s2 .9 2 2c0 1.5-2 2-2 3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
        <circle cx="7" cy="10.5" r="0.6" fill="currentColor"/>
      </svg>
      Sources
    </div>
    <div class="sources-list">
      ${sources.map((s, i) => `
        <a class="source-chip" href="${s.url}" target="_blank" rel="noopener">
          <span class="source-num">${i+1}</span>
          <span class="source-title">${escH(s.title)}</span>
          <svg class="source-arrow" width="10" height="10" viewBox="0 0 10 10" fill="none">
            <path d="M2 8L8 2M8 2H4M8 2V6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
          </svg>
        </a>
      `).join('')}
    </div>`;
  container.appendChild(box);
}

// ══════════════════════════════════════════════════════════════
// SEND
// ══════════════════════════════════════════════════════════════
sendBtn.addEventListener('click', handleSend);

async function handleSend() {
  const raw = chatInput.value.trim();
  if (!raw && pendingFiles.length === 0) return;

  // Commands
  if (raw.startsWith('/')) {
    renderMessage('user', raw, [], true);
    chatInput.value = ''; chatInput.style.height = 'auto';
    sendBtn.disabled = true;
    handleCommand(raw.slice(1));
    return;
  }

  // Games
  if (typeof isPlayingRPS !== 'undefined' && isPlayingRPS) {
    renderMessage('user', raw, [], true);
    chatInput.value = ''; chatInput.style.height = 'auto';
    sendBtn.disabled = true;
    playRPS(raw.toLowerCase()); return;
  }
  if (typeof isPlayingGuess !== 'undefined' && isPlayingGuess) {
    renderMessage('user', raw, [], true);
    chatInput.value = ''; chatInput.style.height = 'auto';
    sendBtn.disabled = true;
    playGuess(raw); return;
  }

  const attachments = [...pendingFiles];
  pendingFiles = []; updateFilePreviews();

  renderMessage('user', raw, attachments, true);
  chatInput.value = ''; chatInput.style.height = 'auto';
  sendBtn.disabled = true;
  if (typeof playSoundSend === 'function') playSoundSend();

  const conv = (typeof getActiveConv !== 'undefined') ? getActiveConv() : null;
  if (conv) autoTitle(conv, raw);

  showTyping();

  try {
    if (currentMode === 'code') {
      const result = await generateCode(raw);
      hideTyping();
      displayCode(result.language, result.code, result.explanation);

    } else if (currentMode === 'image') {
      hideTyping();
      renderMessage('ai', '🎨 Generating your image… this takes 5–15 seconds.', [], false);
      try {
        const url = await generateImage(raw);
        const msgs = document.getElementById('chat-messages');
        const last = msgs.lastElementChild;
        if (last && last.querySelector('.msg-text')?.textContent?.includes('Generating')) last.remove();
        displayImage(raw, url);
      } catch(imgErr) {
        renderMessage('ai', '❌ Image generation failed: ' + imgErr.message, [], false);
      }

    } else {
      // ── Link keyword detection — show sources immediately ──
      const linkKeywords = /\b(youtube|google|github|link|links|url|website|video|tutorial|source|reference|article|docs|documentation|search|find me|show me|give me)\b/i;
      const wantsLinks = linkKeywords.test(raw);

      const prompt = buildPrompt(raw, attachments);
      let answered = false;

      // Step 0: Check Knowledge Base first
      if (typeof window.checkKBAnswer === 'function') {
        const kbMatch = window.checkKBAnswer(raw);
        if (kbMatch) {
          hideTyping();
          renderMessage('ai',
            `📚 **From Knowledge Base:**

${kbMatch.a}

---
*Source: ${kbMatch.q}*`,
            [], true
          );
          answered = true;
        }
      }

      // Step 1: Try server /apicall (Pollinations free AI)
      try {
        const r = await fetch('/apicall', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: prompt })
        });
        const d = await r.json();
        if (d.answer && d.answer.trim()) {
          hideTyping();
          // If user asked for links, prepend direct source cards before AI reply
          if (wantsLinks) {
            const enc = encodeURIComponent(raw.trim().slice(0,100));
            const directLinks = [
              { title: raw + ' — YouTube', url: 'https://www.youtube.com/results?search_query=' + enc, type: 'youtube', icon: '▶️', desc: 'YouTube search' },
              { title: raw + ' — Google',  url: 'https://www.google.com/search?q=' + enc,              type: 'google',  icon: '🔍', desc: 'Google search' },
              { title: raw + ' — GitHub',  url: 'https://github.com/search?q=' + enc + '&type=repositories', type: 'github', icon: '🐙', desc: 'GitHub repos' },
            ];
            renderMessage('ai', '🔗 Here are direct links for your query:', [], true);
            const linkRow = document.getElementById('chat-messages').lastElementChild;
            if (linkRow) renderSources(directLinks, linkRow.querySelector('.msg-body'));
          }
          renderMessage('ai', d.answer, [], true);
          if (typeof playSoundReceive === 'function') playSoundReceive();
          if (typeof speakIfEnabled === 'function') speakIfEnabled(d.answer);
          fetchSources(raw).then(srcs => {
            const lastRow = document.getElementById('chat-messages').lastElementChild;
            if (lastRow) renderSources(srcs, lastRow.querySelector('.msg-body'));
          });
          answered = true;
        }
      } catch(e1) {
        console.warn('Server failed:', e1.message);
      }

      // Step 2: Try Puter AI in browser (free GPT-4o mini)
      if (!answered) {
        try {
          let attempts = 0;
          while ((typeof puter === 'undefined' || !puter?.ai?.chat) && attempts < 15) {
            await new Promise(r => setTimeout(r, 300));
            attempts++;
          }
          if (typeof puter !== 'undefined' && puter?.ai?.chat) {
            const r = await puter.ai.chat(prompt, { model: 'gpt-4o-mini' });
            const ans = typeof r === 'string' ? r
              : (r?.message?.content
                ? (typeof r.message.content === 'string'
                  ? r.message.content
                  : r.message.content.map(x => x?.text||'').join(''))
                : r?.text || r?.content || '');
            if (ans && ans.trim()) {
              hideTyping();
              renderMessage('ai', ans, [], true);
              answered = true;
            }
          }
        } catch(e2) {
          console.warn('Puter failed:', e2.message);
        }
      }

      // Step 3: Nothing worked
      if (!answered) {
        hideTyping();
        renderMessage('ai',
          '⚠️ AI is not responding.\n\n' +
          'Please check:\n' +
          '• Is `node server.js` running in terminal?\n' +
          '• Is your internet connected?\n' +
          '• Try Ctrl+Shift+R to refresh',
          [], false
        );
      }
    }
  } catch(err) {
    hideTyping();
    if (typeof playSoundError === 'function') playSoundError();
    renderMessage('ai', '❌ Error: ' + err.message, [], false);
  } finally {
    // ALWAYS re-enable send button
    sendBtn.disabled = false;
  }
}