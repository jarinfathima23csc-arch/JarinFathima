require('dotenv').config();

// Fix: only log that variables are loaded, NEVER log actual secret values
console.log('PORT:',       process.env.PORT       ? '✅ Set' : '❌ Missing');
console.log('GEMINI_KEY:', process.env.GEMINI_API_KEY ? '✅ Set' : '❌ Missing');

// Fix: removed DB_URL and SECRET_KEY — not defined in .env and not used in project