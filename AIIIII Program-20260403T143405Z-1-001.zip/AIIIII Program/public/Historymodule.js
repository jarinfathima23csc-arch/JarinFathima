// ============================================================
// HistoryModule.js — Complete Backup & Restore System
// Handles: Export (JSON/TXT), Import (Restore/Merge),
//          Search across chats, Manage (delete/clear)
// ============================================================

(function () {

  // ── Internal state for import ──────────────────────────────
  let _importedData = null;

  // ══════════════════════════════════════════════════════════
  // OPEN / CLOSE
  // ══════════════════════════════════════════════════════════
  const historyModalBtn = document.getElementById('history-modal-btn');
  const hmClose         = document.getElementById('hm-close');
  const hmOverlay       = document.getElementById('history-modal');

  if (historyModalBtn) {
    historyModalBtn.addEventListener('click', openHM);
  }
  if (hmClose) {
    hmClose.addEventListener('click', closeHM);
  }
  if (hmOverlay) {
    hmOverlay.addEventListener('click', e => {
      if (e.target === hmOverlay) closeHM();
    });
  }

  function openHM() {
    const modal = document.getElementById('history-modal');
    if (!modal) return;
    modal.classList.remove('hidden');
    refreshStats();
    switchHMTab('export');     // always open on Export tab
    populateSingleSelect();
    renderManageList();
  }

  function closeHM() {
    const modal = document.getElementById('history-modal');
    if (modal) modal.classList.add('hidden');
    _importedData = null;
  }

  // keep old window.openHistoryModal / closeHistoryModal working
  window.openHistoryModal  = openHM;
  window.closeHistoryModal = closeHM;

  // ══════════════════════════════════════════════════════════
  // STATS BAR
  // ══════════════════════════════════════════════════════════
  function refreshStats() {
    const convs   = (typeof conversations !== 'undefined') ? conversations : [];
    const total   = convs.length;
    const msgCount = convs.reduce((a, c) => a + (c.messages ? c.messages.length : 0), 0);

    // Storage size
    let storageSize = '—';
    try {
      const key  = 'jameeai_history_' + ((typeof currentUser !== 'undefined') ? currentUser : 'guest');
      const data = localStorage.getItem(key) || '';
      storageSize = (data.length * 2 / 1024).toFixed(1) + ' KB';
    } catch(e) {}

    const valChats = document.getElementById('hm-total-chats');
    const valMsgs  = document.getElementById('hm-total-msgs');
    const valStore = document.getElementById('hm-storage');
    if (valChats) valChats.textContent = total;
    if (valMsgs)  valMsgs.textContent  = msgCount;
    if (valStore) valStore.textContent  = storageSize;
  }

  // ══════════════════════════════════════════════════════════
  // TAB SWITCHING
  // ══════════════════════════════════════════════════════════
  document.querySelectorAll('.hm-tab').forEach(btn => {
    btn.addEventListener('click', () => switchHMTab(btn.dataset.tab));
  });

  function switchHMTab(name) {
    document.querySelectorAll('.hm-tab').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === name);
    });
    document.querySelectorAll('.hm-panel').forEach(p => {
      p.classList.toggle('active',  p.id === 'hm-tab-' + name);
      p.classList.toggle('hidden', p.id !== 'hm-tab-' + name);
    });
    // Lazy-load per tab
    if (name === 'manage') renderManageList();
    if (name === 'search') document.getElementById('hm-search-input')?.focus();
  }

  // ══════════════════════════════════════════════════════════
  // EXPORT TAB
  // ══════════════════════════════════════════════════════════

  // ── Helper: download a blob ─────────────────────────────
  function download(filename, content, mime) {
    const a = document.createElement('a');
    a.href     = URL.createObjectURL(new Blob([content], { type: mime }));
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  }

  // ── Build JSON backup object ────────────────────────────
  function buildBackupJSON(convList) {
    return JSON.stringify({
      version:     '2.0',
      app:         'Jamee AI',
      user:        (typeof currentUser !== 'undefined') ? currentUser : 'unknown',
      exportedAt:  new Date().toISOString(),
      totalChats:  convList.length,
      totalMsgs:   convList.reduce((a, c) => a + (c.messages ? c.messages.length : 0), 0),
      conversations: convList
    }, null, 2);
  }

  // ── Build plain-text backup ─────────────────────────────
  function buildBackupTXT(convList) {
    const lines = [];
    lines.push('═══════════════════════════════════════════');
    lines.push('  JAMEE AI — CHAT BACKUP');
    lines.push('  Exported: ' + new Date().toLocaleString());
    lines.push('  User: ' + ((typeof currentUser !== 'undefined') ? currentUser : 'unknown'));
    lines.push('  Total chats: ' + convList.length);
    lines.push('═══════════════════════════════════════════');
    lines.push('');

    convList.forEach((conv, i) => {
      lines.push('───────────────────────────────────────────');
      lines.push('Chat ' + (i + 1) + ': ' + (conv.title || 'Untitled'));
      lines.push('Messages: ' + (conv.messages ? conv.messages.length : 0));
      lines.push('───────────────────────────────────────────');
      if (conv.messages && conv.messages.length > 0) {
        conv.messages.forEach(m => {
          const who = m.role === 'user' ? '👤 You' : '🤖 Jamee AI';
          lines.push(who + ':');
          lines.push(m.content || '');
          lines.push('');
        });
      } else {
        lines.push('(No messages)');
        lines.push('');
      }
    });
    return lines.join('\n');
  }

  // ── Date stamp for filenames ────────────────────────────
  function dateStamp() {
    return new Date().toISOString().slice(0, 10);
  }

  // ── Export ALL — JSON ───────────────────────────────────
  const btnAllJSON = document.getElementById('hm-export-all-json');
  if (btnAllJSON) {
    btnAllJSON.addEventListener('click', () => {
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      if (convs.length === 0) { setNote('hm-export-note', '⚠️ No chats to export.', 'warn'); return; }
      download('jameeai-backup-' + dateStamp() + '.json', buildBackupJSON(convs), 'application/json');
      setNote('hm-export-note', '✅ Exported ' + convs.length + ' chat(s) as JSON!', 'ok');
      if (typeof showToast === 'function') showToast('✅ JSON backup downloaded!');
    });
  }

  // ── Export ALL — TXT ────────────────────────────────────
  const btnAllTXT = document.getElementById('hm-export-all-txt');
  if (btnAllTXT) {
    btnAllTXT.addEventListener('click', () => {
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      if (convs.length === 0) { setNote('hm-export-note', '⚠️ No chats to export.', 'warn'); return; }
      download('jameeai-backup-' + dateStamp() + '.txt', buildBackupTXT(convs), 'text/plain');
      setNote('hm-export-note', '✅ Exported ' + convs.length + ' chat(s) as TXT!', 'ok');
      if (typeof showToast === 'function') showToast('✅ TXT backup downloaded!');
    });
  }

  // ── Populate single-chat dropdown ──────────────────────
  function populateSingleSelect() {
    const sel = document.getElementById('hm-single-select');
    if (!sel) return;
    const convs = (typeof conversations !== 'undefined') ? conversations : [];
    sel.innerHTML = '';
    if (convs.length === 0) {
      sel.innerHTML = '<option value="">No chats available</option>';
      return;
    }
    convs.forEach(c => {
      const opt = document.createElement('option');
      opt.value       = c.id;
      opt.textContent = c.title + ' (' + (c.messages ? c.messages.length : 0) + ' msgs)';
      sel.appendChild(opt);
    });
  }

  // ── Export ONE — JSON ───────────────────────────────────
  const btnOneJSON = document.getElementById('hm-export-one-json');
  if (btnOneJSON) {
    btnOneJSON.addEventListener('click', () => {
      const sel  = document.getElementById('hm-single-select');
      const id   = sel ? sel.value : '';
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      const conv = convs.find(c => c.id === id);
      if (!conv) { setNote('hm-export-note', '⚠️ Select a chat first.', 'warn'); return; }
      const safe = conv.title.replace(/[^a-z0-9]/gi, '_').slice(0, 30);
      download('jameeai-' + safe + '-' + dateStamp() + '.json', buildBackupJSON([conv]), 'application/json');
      setNote('hm-export-note', '✅ "' + conv.title + '" exported as JSON!', 'ok');
    });
  }

  // ── Export ONE — TXT ────────────────────────────────────
  const btnOneTXT = document.getElementById('hm-export-one-txt');
  if (btnOneTXT) {
    btnOneTXT.addEventListener('click', () => {
      const sel  = document.getElementById('hm-single-select');
      const id   = sel ? sel.value : '';
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      const conv = convs.find(c => c.id === id);
      if (!conv) { setNote('hm-export-note', '⚠️ Select a chat first.', 'warn'); return; }
      const safe = conv.title.replace(/[^a-z0-9]/gi, '_').slice(0, 30);
      download('jameeai-' + safe + '-' + dateStamp() + '.txt', buildBackupTXT([conv]), 'text/plain');
      setNote('hm-export-note', '✅ "' + conv.title + '" exported as TXT!', 'ok');
    });
  }

  // ══════════════════════════════════════════════════════════
  // IMPORT TAB
  // ══════════════════════════════════════════════════════════
  const fileInput  = document.getElementById('hm-file-input');
  const uploadText = document.getElementById('hm-upload-text');
  const restoreBtn = document.getElementById('hm-restore-btn');
  const mergeBtn   = document.getElementById('hm-merge-btn');
  const importWarn = document.getElementById('hm-import-warn');

  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;
      if (!file.name.endsWith('.json')) {
        setNote('hm-import-note', '❌ Only .json backup files are supported.', 'err');
        return;
      }
      const reader = new FileReader();
      reader.onload = e => {
        try {
          const data = JSON.parse(e.target.result);
          if (!data.conversations || !Array.isArray(data.conversations)) {
            setNote('hm-import-note', '❌ Invalid backup file — missing conversations array.', 'err');
            _importedData = null;
            if (restoreBtn) restoreBtn.disabled = true;
            if (mergeBtn)   mergeBtn.disabled   = true;
            return;
          }
          _importedData = data;
          const n = data.conversations.length;
          if (uploadText) uploadText.textContent = '✅ ' + file.name + ' (' + n + ' chat' + (n !== 1 ? 's' : '') + ')';
          setNote('hm-import-note', 'Found ' + n + ' chat(s). Choose Restore or Merge below.', 'ok');
          if (restoreBtn) restoreBtn.disabled = false;
          if (mergeBtn)   mergeBtn.disabled   = false;
          if (importWarn) importWarn.classList.remove('hidden');
        } catch(err) {
          setNote('hm-import-note', '❌ Could not read file. Is it a valid JSON backup?', 'err');
          _importedData = null;
          if (restoreBtn) restoreBtn.disabled = true;
          if (mergeBtn)   mergeBtn.disabled   = true;
        }
      };
      reader.readAsText(file);
      fileInput.value = '';
    });
  }

  // ── Restore (replace ALL current chats) ────────────────
  if (restoreBtn) {
    restoreBtn.addEventListener('click', () => {
      if (!_importedData) return;
      if (!confirm('⚠️ This will DELETE all your current chats and replace them with the backup. Continue?')) return;
      if (typeof conversations !== 'undefined') {
        conversations.length = 0;
        _importedData.conversations.forEach(c => conversations.push(c));
        if (typeof saveConversations === 'function') saveConversations();
        if (typeof renderHistory     === 'function') renderHistory();
        if (typeof createNewConversation === 'function' && conversations.length === 0) createNewConversation();
        else if (typeof switchConversation === 'function' && conversations.length > 0) switchConversation(conversations[0].id);
      }
      const n = _importedData.conversations.length;
      setNote('hm-import-note', '✅ Restored ' + n + ' chat(s) successfully!', 'ok');
      if (typeof showToast === 'function') showToast('✅ ' + n + ' chat(s) restored!');
      refreshStats();
      _importedData = null;
      if (restoreBtn) restoreBtn.disabled = true;
      if (mergeBtn)   mergeBtn.disabled   = true;
      if (importWarn) importWarn.classList.add('hidden');
      if (uploadText) uploadText.textContent = 'Click to choose .json backup file';
    });
  }

  // ── Merge (keep existing, add new from backup) ──────────
  if (mergeBtn) {
    mergeBtn.addEventListener('click', () => {
      if (!_importedData) return;
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      let added = 0;
      _importedData.conversations.forEach(c => {
        if (!convs.find(x => x.id === c.id)) {
          convs.push(c);
          added++;
        }
      });
      if (typeof saveConversations === 'function') saveConversations();
      if (typeof renderHistory     === 'function') renderHistory();
      setNote('hm-import-note', '✅ Merged! Added ' + added + ' new chat(s).', 'ok');
      if (typeof showToast === 'function') showToast('✅ Merged ' + added + ' new chat(s)!');
      refreshStats();
      _importedData = null;
      if (restoreBtn) restoreBtn.disabled = true;
      if (mergeBtn)   mergeBtn.disabled   = true;
      if (importWarn) importWarn.classList.add('hidden');
      if (uploadText) uploadText.textContent = 'Click to choose .json backup file';
    });
  }

  // ══════════════════════════════════════════════════════════
  // SEARCH TAB — search across ALL chats & messages
  // ══════════════════════════════════════════════════════════
  const hmSearchInput   = document.getElementById('hm-search-input');
  const hmSearchResults = document.getElementById('hm-search-results');

  if (hmSearchInput) {
    hmSearchInput.addEventListener('input', () => {
      const q = hmSearchInput.value.trim().toLowerCase();
      if (!q) {
        hmSearchResults.innerHTML = '<p class="hm-empty">Type to search your chat history.</p>';
        return;
      }
      doSearch(q);
    });
  }

  function doSearch(q) {
    const convs   = (typeof conversations !== 'undefined') ? conversations : [];
    const results = [];

    convs.forEach(conv => {
      (conv.messages || []).forEach((msg, mi) => {
        if (msg.content && msg.content.toLowerCase().includes(q)) {
          const idx = msg.content.toLowerCase().indexOf(q);
          const start  = Math.max(0, idx - 40);
          const end    = Math.min(msg.content.length, idx + q.length + 60);
          let snippet  = (start > 0 ? '…' : '') + msg.content.slice(start, end) + (end < msg.content.length ? '…' : '');
          // Highlight match
          const re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
          snippet = snippet.replace(re, '<mark class="hm-hl">$1</mark>');
          results.push({ conv, msg, snippet, mi });
        }
      });
    });

    if (results.length === 0) {
      hmSearchResults.innerHTML = '<p class="hm-empty">No results found for "' + escHM(q) + '".</p>';
      return;
    }

    hmSearchResults.innerHTML = '<p class="hm-search-count">' + results.length + ' result' + (results.length !== 1 ? 's' : '') + '</p>';
    results.forEach(r => {
      const row = document.createElement('div');
      row.className = 'hm-search-item';
      row.innerHTML = `
        <div class="hm-si-top">
          <span class="hm-si-role ${r.msg.role === 'user' ? 'hm-role-user' : 'hm-role-ai'}">
            ${r.msg.role === 'user' ? '👤 You' : '🤖 AI'}
          </span>
          <span class="hm-si-chat">${escHM(r.conv.title)}</span>
        </div>
        <div class="hm-si-snippet">${r.snippet}</div>`;
      row.addEventListener('click', () => {
        if (typeof switchConversation === 'function') switchConversation(r.conv.id);
        closeHM();
      });
      hmSearchResults.appendChild(row);
    });
  }

  // ══════════════════════════════════════════════════════════
  // MANAGE TAB — list all chats with delete buttons
  // ══════════════════════════════════════════════════════════
  function renderManageList() {
    const list  = document.getElementById('hm-manage-list');
    if (!list) return;
    const convs = (typeof conversations !== 'undefined') ? conversations : [];
    list.innerHTML = '';

    if (convs.length === 0) {
      list.innerHTML = '<p class="hm-empty">No chats yet.</p>';
      return;
    }

    convs.forEach(conv => {
      const msgCount = conv.messages ? conv.messages.length : 0;
      const isActive = (typeof activeConvId !== 'undefined') && conv.id === activeConvId;
      const row = document.createElement('div');
      row.className = 'hm-manage-row' + (isActive ? ' hm-manage-active' : '');
      row.innerHTML = `
        <div class="hm-mr-info">
          <span class="hm-mr-title">${escHM(conv.title)}</span>
          <span class="hm-mr-count">${msgCount} msg${msgCount !== 1 ? 's' : ''}</span>
        </div>
        <div class="hm-mr-btns">
          <button class="hm-mr-open" title="Open chat">
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M2 6.5h9M7.5 3l3.5 3.5L7.5 10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <button class="hm-mr-del" title="Delete chat">
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M2 3.5h9M5 3.5V2.5a.5.5 0 01.5-.5h2a.5.5 0 01.5.5v1M10.5 3.5l-.5 7a1 1 0 01-1 1h-4a1 1 0 01-1-1l-.5-7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
          </button>
        </div>`;
      row.querySelector('.hm-mr-open').addEventListener('click', () => {
        if (typeof switchConversation === 'function') switchConversation(conv.id);
        closeHM();
      });
      row.querySelector('.hm-mr-del').addEventListener('click', () => {
        if (!confirm('Delete "' + conv.title + '"?')) return;
        const convArr = (typeof conversations !== 'undefined') ? conversations : [];
        const idx = convArr.findIndex(c => c.id === conv.id);
        if (idx !== -1) convArr.splice(idx, 1);
        if (typeof activeConvId !== 'undefined' && typeof conversations !== 'undefined') {
          if (activeConvId === conv.id) {
            if (conversations.length > 0 && typeof switchConversation === 'function')
              switchConversation(conversations[0].id);
            else if (typeof createNewConversation === 'function')
              createNewConversation();
          }
        }
        if (typeof saveConversations === 'function') saveConversations();
        if (typeof renderHistory     === 'function') renderHistory();
        if (typeof showToast === 'function') showToast('🗑️ Chat deleted.');
        renderManageList();
        refreshStats();
      });
      list.appendChild(row);
    });
  }

  // ── Clear ALL button ─────────────────────────────────────
  const clearAllBtn = document.getElementById('hm-clear-all-btn');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => {
      const convs = (typeof conversations !== 'undefined') ? conversations : [];
      if (convs.length === 0) { if (typeof showToast === 'function') showToast('⚠️ No chats to clear.'); return; }
      if (!confirm('Delete ALL ' + convs.length + ' conversation(s)? This cannot be undone.')) return;
      convs.length = 0;
      if (typeof saveConversations    === 'function') saveConversations();
      if (typeof createNewConversation=== 'function') createNewConversation();
      if (typeof renderHistory        === 'function') renderHistory();
      renderManageList();
      refreshStats();
      if (typeof showToast === 'function') showToast('🗑️ All history cleared.');
      closeHM();
    });
  }

  // ══════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════
  function setNote(id, msg, type) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = msg;
    el.style.color = type === 'ok' ? '#10a37f' : type === 'warn' ? '#f59e0b' : '#ef4444';
    setTimeout(() => { if (el) el.textContent = ''; }, 4000);
  }

  function escHM(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

})();