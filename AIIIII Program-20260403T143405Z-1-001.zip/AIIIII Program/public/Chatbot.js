// ============================================================
// Chatbot.js — Auth, Sidebar, History, Commands, Games
// ============================================================

const loginScreen    = document.getElementById('login-screen');
const registerScreen = document.getElementById('register-screen');
const chatboxScreen  = document.getElementById('chatbox-screen');
const loginForm      = document.getElementById('login-form');
const registerForm   = document.getElementById('register-form');
const goToRegister   = document.getElementById('go-to-register');
const goToLogin      = document.getElementById('go-to-login');
const logoutBtn      = document.getElementById('logout-btn');
const sidebar        = document.getElementById('sidebar');
const sidebarToggle  = document.getElementById('sidebar-toggle');
const menuBtn        = document.getElementById('menu-btn');
const sidebarOverlay = document.getElementById('sidebar-overlay');
const newChatBtn     = document.getElementById('new-chat-btn');
const historyList    = document.getElementById('history-list');
const userAvatar     = document.getElementById('user-avatar');
const userNameDisp   = document.getElementById('user-name-display');
const searchInput    = document.getElementById('search-input');
const welcomeTitle   = document.getElementById('welcome-title');

// ── Users (localStorage) ──────────────────────────────────────
function loadUsers() {
  try { return JSON.parse(localStorage.getItem('jameeai_users') || '{}'); } catch(e) { return {}; }
}
function saveUsers(obj) {
  try { localStorage.setItem('jameeai_users', JSON.stringify(obj)); } catch(e) {}
}
const users = loadUsers();

// ── State ─────────────────────────────────────────────────────
let currentUser   = null;
let conversations = [];
let activeConvId  = null;
let firstMessage  = true;

// ── Game states ───────────────────────────────────────────────
let isPlayingRPS   = false;
let isPlayingGuess = false;
let guessNumber    = null;

// ══════════════════════════════════════════════════════════════
// SCREEN CONTROL
// ══════════════════════════════════════════════════════════════
function showScreen(s) {
  [loginScreen, registerScreen, chatboxScreen].forEach(el => el.classList.add('hidden'));
  s.classList.remove('hidden');
}

// ══════════════════════════════════════════════════════════════
// AUTH
// ══════════════════════════════════════════════════════════════
goToRegister.addEventListener('click', e => { e.preventDefault(); clearErrors(); showScreen(registerScreen); });
goToLogin.addEventListener('click',    e => { e.preventDefault(); clearErrors(); showScreen(loginScreen); });

loginForm.addEventListener('submit', e => {
  e.preventDefault();
  const u = document.getElementById('login-username').value.trim();
  const p = document.getElementById('login-password').value;
  if (!u) return showError('login-error', 'Enter username.');
  if (!p) return showError('login-error', 'Enter password.');
  const latest = loadUsers();
  Object.assign(users, latest);
  if (!users[u] || users[u] !== p) return showError('login-error', 'Wrong username or password.');
  clearErrors();
  startSession(u);
});

registerForm.addEventListener('submit', e => {
  e.preventDefault();
  const u = document.getElementById('register-username').value.trim();
  const p = document.getElementById('register-password').value;
  const err = validate(u, p);
  if (err) return showError('register-error', err);
  if (users[u]) return showError('register-error', 'Username already taken.');
  users[u] = p;
  saveUsers(users);
  clearErrors();
  showToast('Registered! Please sign in.');
  setTimeout(() => {
    document.getElementById('login-username').value = u;
    showScreen(loginScreen);
  }, 1500);
});

logoutBtn.addEventListener('click', () => {
  currentUser = null; conversations = []; activeConvId = null; firstMessage = true;
  isPlayingRPS = false; isPlayingGuess = false;
  document.getElementById('login-username').value = '';
  document.getElementById('login-password').value = '';
  showScreen(loginScreen);
});

function validate(u, p) {
  if (!u || u.length < 3) return 'Username: at least 3 characters.';
  if (!p || p.length < 4) return 'Password: at least 4 characters.';
  return null;
}
function showError(id, msg) { const el = document.getElementById(id); if (el) el.textContent = msg; }
function clearErrors() { ['login-error','register-error'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = ''; }); }

// ══════════════════════════════════════════════════════════════
// SESSION
// ══════════════════════════════════════════════════════════════
function startSession(u) {
  currentUser = u;
  userAvatar.textContent   = u[0].toUpperCase();
  userNameDisp.textContent = u;
  if (welcomeTitle) welcomeTitle.textContent = 'What can I help with?';
  showScreen(chatboxScreen);

  // Restore saved history
  const saved = loadSavedConversations();
  if (saved && saved.length > 0) {
    conversations = saved;
    activeConvId  = saved[0].id;
    renderHistory();
    clearChatUI();
    saved[0].messages.forEach(m => renderMessage(m.role, m.content, m.attachments || [], false));
    if (saved[0].messages.length > 0) firstMessage = false;
    showToast('📂 ' + saved.length + ' chat(s) restored!');
  } else {
    conversations = [];
    createNewConversation();
  }

  // Admin button visibility
  const admins = JSON.parse(localStorage.getItem('jameeai_admins') || '["admin"]');
  const adminBtn = document.getElementById('admin-btn');
  if (adminBtn) {
    if (admins.includes(u)) {
      adminBtn.classList.remove('admin-hidden');
      adminBtn.classList.add('admin-visible');
    } else {
      adminBtn.classList.add('admin-hidden');
      adminBtn.classList.remove('admin-visible');
    }
  }
}

// ══════════════════════════════════════════════════════════════
// CONVERSATIONS
// ══════════════════════════════════════════════════════════════
function createNewConversation() {
  const id   = 'c' + Date.now();
  const conv = { id, title: 'New chat', messages: [] };
  conversations.unshift(conv);
  activeConvId = id;
  renderHistory();
  clearChatUI();
  closeSidebarMobile();
}

function getActiveConv() {
  return conversations.find(c => c.id === activeConvId) || null;
}

function switchConversation(id) {
  activeConvId = id;
  renderHistory();
  clearChatUI();
  const conv = getActiveConv();
  if (!conv) return;
  conv.messages.forEach(m => renderMessage(m.role, m.content, m.attachments || [], false));
  if (conv.messages.length > 0) firstMessage = false;
  closeSidebarMobile();
}

function deleteConversation(id) {
  if (!confirm('Delete this conversation?')) return;
  conversations = conversations.filter(c => c.id !== id);
  if (activeConvId === id) {
    if (conversations.length > 0) switchConversation(conversations[0].id);
    else createNewConversation();
  } else renderHistory();
  saveConversations();
}

function renameConversation(id, newTitle) {
  const c = conversations.find(x => x.id === id);
  if (c && newTitle.trim()) { c.title = newTitle.trim(); renderHistory(); saveConversations(); }
}

function autoTitle(conv, text) {
  if (conv.title === 'New chat' && text.length > 2) {
    conv.title = text.slice(0, 40) + (text.length > 40 ? '…' : '');
    renderHistory();
    saveConversations();
  }
}

// ══════════════════════════════════════════════════════════════
// SIDEBAR HISTORY
// ══════════════════════════════════════════════════════════════
function renderHistory(filter) {
  historyList.innerHTML = '';
  const list = filter
    ? conversations.filter(c => c.title.toLowerCase().includes(filter.toLowerCase()))
    : conversations;

  list.forEach(conv => {
    const item = document.createElement('div');
    item.className = 'history-item' + (conv.id === activeConvId ? ' active' : '');

    const icon = document.createElement('span');
    icon.className = 'h-icon';
    icon.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 3a1 1 0 011-1h8a1 1 0 011 1v6a1 1 0 01-1 1H8l-3 2V10H3a1 1 0 01-1-1V3z" stroke="currentColor" stroke-width="1.2"/></svg>`;

    const title = document.createElement('div');
    title.className = 'history-title';
    title.textContent = conv.title;

    const acts = document.createElement('div');
    acts.className = 'history-actions';

    const renBtn = document.createElement('button');
    renBtn.className = 'h-btn'; renBtn.title = 'Rename';
    renBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M8.5 1.5a1.5 1.5 0 012 2L4 10H2V8L8.5 1.5z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>`;
    renBtn.onclick = e => { e.stopPropagation(); startRename(item, title, conv.id); };

    const delBtn = document.createElement('button');
    delBtn.className = 'h-btn del'; delBtn.title = 'Delete';
    delBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 3h8M5 3V2h2v1M4.5 3v6M7.5 3v6M3 3l.5 7h5L9 3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`;
    delBtn.onclick = e => { e.stopPropagation(); deleteConversation(conv.id); };

    acts.appendChild(renBtn); acts.appendChild(delBtn);
    item.appendChild(icon); item.appendChild(title); item.appendChild(acts);
    item.addEventListener('click', () => switchConversation(conv.id));
    historyList.appendChild(item);
  });
}

function startRename(item, titleEl, id) {
  const inp = document.createElement('input');
  inp.className = 'rename-input'; inp.value = titleEl.textContent;
  item.replaceChild(inp, titleEl);
  inp.focus(); inp.select();
  const done = () => renameConversation(id, inp.value || titleEl.textContent);
  inp.addEventListener('blur', done);
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
}

if (searchInput) {
  searchInput.addEventListener('input', () => renderHistory(searchInput.value));
}

// ══════════════════════════════════════════════════════════════
// SIDEBAR TOGGLE
// ══════════════════════════════════════════════════════════════
newChatBtn.addEventListener('click', createNewConversation);

function toggleSidebar() {
  const isMobile = window.innerWidth <= 700;
  if (isMobile) {
    const isOpen = sidebar.classList.contains('open');
    if (isOpen) { sidebar.classList.remove('open'); sidebarOverlay.classList.remove('show'); }
    else { sidebar.classList.add('open'); sidebarOverlay.classList.add('show'); }
  } else {
    sidebar.classList.toggle('collapsed');
    sidebarOverlay.classList.remove('show');
  }
}

if (sidebarToggle) sidebarToggle.addEventListener('click', toggleSidebar);
if (menuBtn)       menuBtn.addEventListener('click', toggleSidebar);
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebarMobile);

function closeSidebarMobile() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('show');
}

// ══════════════════════════════════════════════════════════════
// CHAT UI
// ══════════════════════════════════════════════════════════════
function clearChatUI() {
  const msgs = document.getElementById('chat-messages');
  firstMessage = true;
  msgs.innerHTML = `
    <div id="welcome-state" class="welcome-wrap">
      <div class="welcome-greeting">
        <div class="welcome-logo">
          <svg width="48" height="48" viewBox="0 0 28 28" fill="none">
            <path d="M14 2L26 8V20L14 26L2 20V8L14 2Z" stroke="rgba(255,255,255,0.3)" stroke-width="1.2" fill="rgba(255,255,255,0.06)"/>
            <path d="M14 8L20 11V17L14 20L8 17V11L14 8Z" fill="rgba(255,255,255,0.9)"/>
          </svg>
        </div>
        <h1 id="welcome-title">What can I help with?</h1>
      </div>
      <div class="welcome-chips">
        <button class="w-chip" onclick="sendChip('Explain neural networks with examples')"><span class="chip-icon">🧠</span>Neural networks</button>
        <button class="w-chip" onclick="sendChip('Write a REST API in Node.js with Express')"><span class="chip-icon">⚡</span>Build an API</button>
        <button class="w-chip" onclick="sendChip('A cyberpunk cityscape at night with neon reflections')"><span class="chip-icon">🎨</span>Create image</button>
        <button class="w-chip" onclick="sendChip('Debug my Python code and explain the errors')"><span class="chip-icon">🔍</span>Debug code</button>
        <button class="w-chip" onclick="sendChip('Summarize the key concepts of machine learning')"><span class="chip-icon">📚</span>Summarize topic</button>
        <button class="w-chip" onclick="sendChip('Write a cover letter for a software engineer role')"><span class="chip-icon">✍️</span>Write for me</button>
      </div>
    </div>`;
}

function renderMessage(role, content, attachments, save) {
  if (firstMessage) {
    firstMessage = false;
    const w = document.getElementById('welcome-state');
    if (w) w.style.display = 'none';
  }

  const msgs  = document.getElementById('chat-messages');
  const row   = document.createElement('div');
  row.className = `msg-row ${role === 'user' ? 'user' : 'ai'}`;

  let attHtml = '';
  if (attachments && attachments.length > 0) {
    attHtml = '<div class="msg-attachments">';
    attachments.forEach(a => {
      if (a.type === 'image') attHtml += `<img class="att-img" src="${a.dataUrl}" alt="${escH(a.name)}">`;
      else attHtml += `<div class="att-file">${fileIcon(a.name)} ${escH(a.name)}</div>`;
    });
    attHtml += '</div>';
  }

  let contentHtml = '';
  if (role === 'ai' && typeof marked !== 'undefined') {
    try { contentHtml = marked.parse(String(content)); } catch(e) { contentHtml = escH(content); }
  } else {
    contentHtml = escH(content);
  }

  if (role === 'user') {
    row.innerHTML = `
      <div class="msg-body">
        ${attHtml}
        <div class="msg-bubble"><div class="msg-text">${contentHtml}</div></div>
      </div>`;
  } else {
    const ts = new Date().toLocaleString();
    row.dataset.timestamp = ts;
    row.innerHTML = `
      <div class="msg-body">
        ${attHtml}
        <div class="msg-bubble"><div class="msg-text">${contentHtml}</div></div>
        <div class="ai-action-bar">
          <button class="aab-btn" title="Copy response" onclick="aabCopy(this)">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><rect x="5" y="5" width="9" height="9" rx="1.5" stroke="currentColor" stroke-width="1.4"/><path d="M5 5V4a1 1 0 00-1-1H4a1 1 0 00-1 1v6a1 1 0 001 1h1" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
          </button>
          <button class="aab-btn" title="Good response" onclick="aabThumb(this,'up')">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M5 10V6.5L8 2l1 .5V5h3.5l.5 1-1.5 5H5z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M5 10H3v-4h2" stroke="currentColor" stroke-width="1.3"/></svg>
          </button>
          <button class="aab-btn" title="Bad response" onclick="aabThumb(this,'down')">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11 6v3.5L8 14l-1-.5V11H3.5L3 10l1.5-5H11z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M11 6h2v4h-2" stroke="currentColor" stroke-width="1.3"/></svg>
          </button>
          <button class="aab-btn" title="Share" onclick="aabShare(this)">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-3 3M14 5H6a3 3 0 000 6h1" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <button class="aab-btn" title="Try again" onclick="aabRetry(this)">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8a5 5 0 105-5H6M6 3L3 6l3 3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <div class="aab-more-wrap">
            <button class="aab-btn aab-more-btn" title="More actions" onclick="aabToggleMore(this)">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="3" cy="8" r="1.2" fill="currentColor"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/><circle cx="13" cy="8" r="1.2" fill="currentColor"/></svg>
            </button>
            <div class="aab-dropdown hidden">
              <div class="aab-dd-ts" id="aab-ts-${Date.now()}">${ts}</div>
              <button class="aab-dd-item" onclick="aabReadAloud(this)">
                <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 6H1v4h2l4 3V3L3 6z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M11 5a4 4 0 010 6M13.5 3a7 7 0 010 10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
                Read aloud
              </button>
            </div>
          </div>
        </div>
      </div>`;
  }

  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;

  if (save) {
    const conv = getActiveConv();
    if (conv) conv.messages.push({ role, content, attachments: attachments || [] });
    saveConversations();
  }
}

function displayMessage(from, text) {
  renderMessage(from === 'You' ? 'user' : 'ai', text, [], true);
}

function escH(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fileIcon(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  return ({pdf:'📄',txt:'📝',doc:'📝',docx:'📝',js:'⚡',py:'🐍',html:'🌐',css:'🎨',json:'📋',csv:'📊',md:'📝'})[ext] || '📁';
}

window.copyMsg = function(btn) {
  const text = btn.closest('.msg-body').querySelector('.msg-text').innerText;
  navigator.clipboard.writeText(text).then(() => {
    btn.style.color = '#10a37f';
    setTimeout(() => btn.style.color = '', 1500);
  });
};

// ══════════════════════════════════════════════════════════════
// AI ACTION BAR FUNCTIONS
// ══════════════════════════════════════════════════════════════

// Copy response
window.aabCopy = function(btn) {
  const text = btn.closest('.msg-body').querySelector('.msg-text').innerText;
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.innerHTML;
    btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 7l3.5 3.5 6.5-7" stroke="#10a37f" stroke-width="1.5" stroke-linecap="round"/></svg>`;
    btn.style.color = '#10a37f';
    btn.setAttribute('title', 'Copied!');
    setTimeout(() => { btn.innerHTML = orig; btn.style.color = ''; btn.setAttribute('title','Copy response'); }, 2000);
  });
};

// Thumbs up / down
window.aabThumb = function(btn, type) {
  const bar = btn.closest('.ai-action-bar');
  // Toggle active
  bar.querySelectorAll('.aab-btn[onclick*="aabThumb"]').forEach(b => b.classList.remove('aab-active'));
  const already = btn.dataset.voted === type;
  if (!already) { btn.classList.add('aab-active'); btn.dataset.voted = type; }
  else { delete btn.dataset.voted; }
};

// Share — copy link or show toast
window.aabShare = function(btn) {
  const text = btn.closest('.msg-body').querySelector('.msg-text').innerText;
  const url  = window.location.href;
  if (navigator.share) {
    navigator.share({ title: 'Jamee AI', text: text.slice(0,200), url }).catch(() => {});
  } else {
    navigator.clipboard.writeText(url).then(() => {
      const orig = btn.innerHTML;
      btn.setAttribute('title','Link copied!');
      btn.style.color = '#10a37f';
      setTimeout(() => { btn.style.color = ''; btn.setAttribute('title','Share'); }, 2000);
    });
  }
};

// Retry — resend last user message
window.aabRetry = function(btn) {
  const row   = btn.closest('.msg-row');
  const msgs  = document.getElementById('chat-messages');
  const rows  = Array.from(msgs.querySelectorAll('.msg-row'));
  const idx   = rows.indexOf(row);

  // Find the user message just before this AI row
  let userText = '';
  for (let i = idx - 1; i >= 0; i--) {
    if (rows[i].classList.contains('user')) {
      userText = rows[i].dataset.rawContent || rows[i].querySelector('.msg-text')?.innerText || '';
      break;
    }
  }
  if (!userText) return;

  // Remove this AI row + re-send
  row.remove();
  const conv = (typeof getActiveConv === 'function') ? getActiveConv() : null;
  if (conv && conv.messages.length > 0 && conv.messages[conv.messages.length-1].role !== 'user') {
    conv.messages.pop();
  }

  const chatInput = document.getElementById('chat-input');
  const sendBtn   = document.getElementById('send-message');
  if (chatInput && sendBtn) {
    chatInput.value = userText;
    chatInput.dispatchEvent(new Event('input'));
    sendBtn.click();
  }
};

// Toggle more dropdown
window.aabToggleMore = function(btn) {
  const dd = btn.closest('.aab-more-wrap').querySelector('.aab-dropdown');
  const isHidden = dd.classList.contains('hidden');
  // Close all other dropdowns
  document.querySelectorAll('.aab-dropdown').forEach(d => d.classList.add('hidden'));
  if (isHidden) dd.classList.remove('hidden');
  // Close on outside click
  if (isHidden) {
    setTimeout(() => {
      document.addEventListener('click', function handler(e) {
        if (!dd.contains(e.target) && e.target !== btn) {
          dd.classList.add('hidden');
          document.removeEventListener('click', handler);
        }
      });
    }, 10);
  }
};

// Read aloud using Web Speech API
window.aabReadAloud = function(btn) {
  const text = btn.closest('.msg-body')?.querySelector('.msg-text')?.innerText || '';
  if (!text) return;
  if (window.speechSynthesis.speaking) {
    window.speechSynthesis.cancel();
    btn.textContent = 'Read aloud';
    return;
  }
  const utt = new SpeechSynthesisUtterance(text);
  utt.rate = 1; utt.pitch = 1;
  utt.onend = () => { btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 6H1v4h2l4 3V3L3 6z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><path d="M11 5a4 4 0 010 6M13.5 3a7 7 0 010 10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg> Read aloud`; };
  btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M3 6H1v4h2l4 3V3L3 6z" fill="currentColor"/></svg> Stop`;
  window.speechSynthesis.speak(utt);
  btn.closest('.aab-dropdown').classList.add('hidden');
};

// ══════════════════════════════════════════════════════════════
// GAMES
// ══════════════════════════════════════════════════════════════
function playRPS(choice) {
  const v = ['rock','paper','scissors'];
  if (!v.includes(choice)) { displayMessage('AI','❌ Type rock, paper, or scissors.'); return; }
  const ai = v[Math.floor(Math.random()*3)];
  let r;
  if (choice === ai) r = `🤝 Tie! We both chose ${choice}.`;
  else if ((choice==='rock'&&ai==='scissors')||(choice==='paper'&&ai==='rock')||(choice==='scissors'&&ai==='paper'))
    r = `🎉 You win! I chose ${ai}.`;
  else r = `😈 You lose! I chose ${ai}.`;
  displayMessage('AI', r);
  isPlayingRPS = false;
  displayMessage('AI', 'Game over! Type /rps to play again.');
}

function playGuess(input) {
  const n = parseInt(input, 10);
  if (isNaN(n)||n<1||n>100) { displayMessage('AI','❌ Enter a number between 1 and 100.'); return; }
  if (n < guessNumber)       displayMessage('AI','📉 Too low! Try higher.');
  else if (n > guessNumber)  displayMessage('AI','📈 Too high! Try lower.');
  else {
    displayMessage('AI',`🎉 Correct! The answer was ${guessNumber}. Type /guess to play again.`);
    isPlayingGuess = false; guessNumber = null;
  }
}

// ══════════════════════════════════════════════════════════════
// COMMANDS
// ══════════════════════════════════════════════════════════════
function handleCommand(cmd) {
  switch(cmd.toLowerCase().trim()) {
    case 'rps':
      isPlayingRPS = true;
      displayMessage('AI', '✊ Rock-Paper-Scissors! Type rock, paper, or scissors.');
      break;
    case 'guess':
      isPlayingGuess = true; guessNumber = Math.floor(Math.random()*100)+1;
      displayMessage('AI', '🔢 Guess a number between 1 and 100!');
      break;
    case 'clear':
      clearChatUI();
      const c = getActiveConv(); if (c) c.messages = [];
      break;
    case 'help':
      displayMessage('AI',
        '## Commands\n\n' +
        '- `/sources` — Get Google, YouTube, GitHub & Wikipedia links for your last question\n' +
        '- `/rps` — Rock Paper Scissors\n' +
        '- `/guess` — Number guessing game\n' +
        '- `/clear` — Clear chat\n' +
        '- `/logout` — Sign out\n' +
        '- `/help` — Show this menu'
      );
      break;
    case 'logout': logoutBtn.click(); break;
    case 'sources': {
      // Get last user message from active conversation
      const sc = getActiveConv();
      const lastUserMsg = sc && sc.messages
        ? [...sc.messages].reverse().find(m => m.role === 'user')
        : null;
      const q = lastUserMsg ? lastUserMsg.content.slice(0, 120) : null;
      if (!q) {
        displayMessage('AI', '🔍 Ask me something first, then type `/sources` to get related links!');
        break;
      }
      displayMessage('AI', `🔍 Finding sources for: **"${q}"**\n\nSearching Google, YouTube, GitHub, Wikipedia…`);
      if (typeof fetchAndShowSources === 'function') {
        fetchAndShowSources(q);
      }
      break;
    }
    default: displayMessage('AI', `❓ Unknown command /${cmd}. Type /help.`);
  }
}

// ══════════════════════════════════════════════════════════════
// TOAST
// ══════════════════════════════════════════════════════════════
function showToast(msg) {
  const old = document.getElementById('toast-popup');
  if (old) old.remove();
  const toast = document.createElement('div');
  toast.id = 'toast-popup';
  toast.className = 'toast-popup';
  toast.innerHTML = `<span class="toast-icon">✅</span><span class="toast-msg">${msg}</span>`;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('toast-show'));
  setTimeout(() => {
    toast.classList.remove('toast-show');
    toast.classList.add('toast-hide');
    setTimeout(() => toast.remove(), 400);
  }, 3000);
}

// ══════════════════════════════════════════════════════════════
// HISTORY SAVE/LOAD
// ══════════════════════════════════════════════════════════════
function historyKey() {
  return 'jameeai_history_' + (currentUser || 'guest');
}
function saveConversations() {
  try { localStorage.setItem(historyKey(), JSON.stringify(conversations)); } catch(e) {}
}
function loadSavedConversations() {
  try {
    const saved = localStorage.getItem(historyKey());
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch(e) {}
  return null;
}
function getStorageSize() {
  try {
    const data = localStorage.getItem(historyKey()) || '';
    return (data.length * 2 / 1024).toFixed(1) + ' KB';
  } catch(e) { return '—'; }
}

// ── History modal — handled by HistoryModule.js ───────────────
// openHistoryModal / closeHistoryModal are set by HistoryModule.js
// These stubs prevent errors if called before module loads
window.openHistoryModal  = window.openHistoryModal  || function() {};
window.closeHistoryModal = window.closeHistoryModal || function() {};

// ══════════════════════════════════════════════════════════════
// MULTILINGUAL
// ══════════════════════════════════════════════════════════════
let selectedLang = localStorage.getItem('jameeai_lang') || 'auto';

const LANG_PROMPTS = {
  auto:'', en:'Always respond in English only.',
  ta:'எப்பொழுதும் தமிழிலேயே பதில் சொல்லவும்.',
  hi:'हमेशा केवल हिंदी में जवाब दें।',
  ar:'أجب دائماً باللغة العربية فقط.',
  fr:'Réponds toujours uniquement en français.',
  de:'Antworte immer nur auf Deutsch.',
  es:'Responde siempre solo en español.',
  zh:'请始终只用中文回答。', ja:'常に日本語のみで回答してください。',
  ko:'항상 한국어로만 대답하세요.',
  pt:'Responda sempre apenas em português.',
  ru:'Всегда отвечай только на русском языке.',
  ml:'എപ്പോഴും മലയാളത്തിൽ മാത്രം മറുപടി നൽകുക.',
  te:'ఎల్లప్పుడూ తెలుగులో మాత్రమే సమాధానం ఇవ్వండి.',
};

const LANG_PLACEHOLDERS = {
  auto:'Ask anything…', en:'Ask anything…',
  ta:'எதுவேனும் கேளுங்கள்…', hi:'कुछ भी पूछें…',
  ar:'اسأل أي شيء…', fr:'Demandez n\'importe quoi…',
  de:'Frag irgendetwas…', es:'Pregunta lo que quieras…',
  zh:'请随意提问…', ja:'何でも聞いてください…',
  ko:'무엇이든 물어보세요…', pt:'Pergunte qualquer coisa…',
  ru:'Спросите что угодно…', ml:'എന്തും ചോദിക്കൂ…',
  te:'ఏదైనా అడగండి…',
};

applyLanguage(selectedLang);

const langBtn      = document.getElementById('lang-btn');
const langDropdown = document.getElementById('lang-dropdown');

if (langBtn) {
  langBtn.addEventListener('click', e => { e.stopPropagation(); langDropdown.classList.toggle('hidden'); });
}
document.addEventListener('click', () => { if (langDropdown) langDropdown.classList.add('hidden'); });

document.querySelectorAll('.lang-option').forEach(opt => {
  opt.addEventListener('click', e => {
    e.stopPropagation();
    const lang = opt.dataset.lang;
    selectedLang = lang;
    localStorage.setItem('jameeai_lang', lang);
    document.getElementById('lang-flag').textContent = opt.dataset.flag;
    document.getElementById('lang-name').textContent = opt.dataset.name.split(' ')[0];
    document.querySelectorAll('.lang-option').forEach(o => o.classList.remove('active'));
    opt.classList.add('active');
    applyLanguage(lang);
    langDropdown.classList.add('hidden');
    showToast('🌐 Language: ' + opt.dataset.name);
  });
});

function applyLanguage(lang) {
  const input = document.getElementById('chat-input');
  if (input) input.placeholder = LANG_PLACEHOLDERS[lang] || 'Ask anything…';
  const msgs = document.getElementById('chat-messages');
  if (msgs) msgs.style.direction = lang === 'ar' ? 'rtl' : 'ltr';
  const flag = document.querySelector(`.lang-option[data-lang="${lang}"]`);
  if (flag) {
    document.getElementById('lang-flag').textContent = flag.dataset.flag;
    document.getElementById('lang-name').textContent = flag.dataset.name.split(' ')[0];
    document.querySelectorAll('.lang-option').forEach(o => o.classList.remove('active'));
    flag.classList.add('active');
  }
}

window.getLanguagePrompt = function() {
  return LANG_PROMPTS[selectedLang] || '';
};
